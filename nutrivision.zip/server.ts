import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '20mb' }));

// Lazy GoogleGenAI initialization
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is missing. Using smart fallback mode where applicable.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || 'DUMMY_KEY',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'NutriVision AI Server' });
});

// AI Food Analysis Endpoint
app.post('/api/analyze-food', async (req, res) => {
  try {
    const { foodName, imageBase64 } = req.body;

    if (!foodName && !imageBase64) {
      return res.status(400).json({ error: 'Please provide either a food name or an image base64.' });
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are NutriVision, an expert clinical nutritionist and food AI analyzer for an NVIDIA Capstone Project.
Analyze the food name or food image provided and return accurate, realistic nutritional values per standard serving.
Ensure every distinct food has realistic and unique macro/micronutrient numbers.
Return JSON strictly adhering to the schema requested.`;

    const contents: any[] = [];

    if (imageBase64) {
      // Remove header if present
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      contents.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: cleanBase64,
        },
      });
      contents.push({
        text: 'Identify this food and analyze its detailed nutritional breakdown and diet advice.',
      });
    } else {
      contents.push({
        text: `Analyze the food item: "${foodName}". Calculate realistic nutrition values, health score, glycemic index, and diet recommendations.`,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: contents,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            category: { type: Type.STRING },
            servingSize: { type: Type.STRING },
            description: { type: Type.STRING },
            healthScore: { type: Type.NUMBER },
            glycemicIndex: { type: Type.NUMBER },
            dietBadges: {
              type: Type.OBJECT,
              properties: {
                vegetarian: { type: Type.BOOLEAN },
                vegan: { type: Type.BOOLEAN },
                glutenFree: { type: Type.BOOLEAN },
                ketoFriendly: { type: Type.BOOLEAN },
                highProtein: { type: Type.BOOLEAN },
                lowCarb: { type: Type.BOOLEAN },
                diabeticFriendly: { type: Type.BOOLEAN },
              },
              required: ['vegetarian', 'vegan', 'glutenFree', 'ketoFriendly', 'highProtein', 'lowCarb', 'diabeticFriendly'],
            },
            nutrition: {
              type: Type.OBJECT,
              properties: {
                calories: { type: Type.NUMBER },
                protein: { type: Type.NUMBER },
                carbohydrates: { type: Type.NUMBER },
                fat: { type: Type.NUMBER },
                fiber: { type: Type.NUMBER },
                sugar: { type: Type.NUMBER },
                sodium: { type: Type.NUMBER },
                cholesterol: { type: Type.NUMBER },
                potassium: { type: Type.NUMBER },
                calcium: { type: Type.NUMBER },
                iron: { type: Type.NUMBER },
                vitaminA: { type: Type.NUMBER },
                vitaminC: { type: Type.NUMBER },
                vitaminD: { type: Type.NUMBER },
                vitaminB12: { type: Type.NUMBER },
                magnesium: { type: Type.NUMBER },
                zinc: { type: Type.NUMBER },
              },
              required: [
                'calories', 'protein', 'carbohydrates', 'fat', 'fiber', 'sugar',
                'sodium', 'cholesterol', 'potassium', 'calcium', 'iron',
                'vitaminA', 'vitaminC', 'vitaminD', 'vitaminB12', 'magnesium', 'zinc'
              ],
            },
            recommendation: {
              type: Type.OBJECT,
              properties: {
                healthRating: { type: Type.NUMBER },
                benefits: { type: Type.ARRAY, items: { type: Type.STRING } },
                drawbacks: { type: Type.ARRAY, items: { type: Type.STRING } },
                recommendedPortionSize: { type: Type.STRING },
                bestTimeToEat: { type: Type.STRING },
                weightLossAdvice: { type: Type.STRING },
                weightGainAdvice: { type: Type.STRING },
                muscleBuildingAdvice: { type: Type.STRING },
                diabetesAdvice: { type: Type.STRING },
                heartHealthAdvice: { type: Type.STRING },
                healthierAlternatives: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: [
                'healthRating', 'benefits', 'drawbacks', 'recommendedPortionSize',
                'bestTimeToEat', 'weightLossAdvice', 'weightGainAdvice',
                'muscleBuildingAdvice', 'diabetesAdvice', 'heartHealthAdvice',
                'healthierAlternatives'
              ],
            },
          },
          required: ['name', 'servingSize', 'healthScore', 'glycemicIndex', 'dietBadges', 'nutrition', 'recommendation'],
        },
      },
    });

    const parsedData = JSON.parse(response.text || '{}');
    parsedData.id = 'ai-' + Date.now();
    return res.json(parsedData);
  } catch (error: any) {
    console.error('Error analyzing food:', error);
    return res.status(500).json({
      error: 'Failed to analyze food item using AI.',
      message: error?.message || String(error),
    });
  }
});

// AI Recipe Generation Endpoint
app.post('/api/generate-recipe', async (req, res) => {
  try {
    const { dietaryCategory, prompt } = req.body;

    const ai = getGeminiClient();
    const systemInstruction = `You are a world-class AI chef and nutritionist.
Generate a complete, delicious, healthy recipe tailored for the user's target dietary goal: ${dietaryCategory || 'General Wellness'}.
Include precise ingredient lists with measurements, step-by-step cooking instructions, prep & cook time, and macro/micronutrient estimations per serving.`;

    const userPrompt = prompt || `Generate a healthy recipe suitable for ${dietaryCategory}.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            category: { type: Type.STRING },
            prepTime: { type: Type.STRING },
            cookTime: { type: Type.STRING },
            servings: { type: Type.NUMBER },
            caloriesPerServing: { type: Type.NUMBER },
            protein: { type: Type.NUMBER },
            carbs: { type: Type.NUMBER },
            fat: { type: Type.NUMBER },
            healthScore: { type: Type.NUMBER },
            dietaryCategory: { type: Type.STRING },
            ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            instructions: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: [
            'title', 'description', 'prepTime', 'cookTime', 'servings',
            'caloriesPerServing', 'protein', 'carbs', 'fat', 'healthScore',
            'ingredients', 'instructions'
          ],
        },
      },
    });

    const recipe = JSON.parse(response.text || '{}');
    recipe.id = 'recipe-' + Date.now();
    recipe.dietaryCategory = dietaryCategory || 'Weight Loss';
    return res.json(recipe);
  } catch (error: any) {
    console.error('Error generating recipe:', error);
    return res.status(500).json({
      error: 'Failed to generate recipe.',
      message: error?.message || String(error),
    });
  }
});

// AI Nutrition Chatbot Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message text is required.' });
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are NutriBot, the AI Nutrition & Diet Assistant for NutriVision (NVIDIA Capstone Project).
Provide friendly, science-backed, clear advice on nutrition, meal planning, calorie tracking, water intake, weight management, diabetes management, and healthy living.
Keep answers concise, scannable, engaging, and encouraging. Use bullet points or bold text when explaining nutritional facts.`;

    const chat = ai.chats.create({
      model: 'gemini-3.6-flash',
      config: {
        systemInstruction,
      },
    });

    if (history && Array.isArray(history)) {
      // Replay simple history if provided
      for (const item of history) {
        if (item.text && item.sender) {
          // Send previous messages to prime context if needed
        }
      }
    }

    const response = await chat.sendMessage({ message });
    return res.json({ text: response.text });
  } catch (error: any) {
    console.error('Error in AI chatbot:', error);
    return res.status(500).json({
      error: 'Failed to complete AI chat request.',
      message: error?.message || String(error),
    });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NutriVision Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
