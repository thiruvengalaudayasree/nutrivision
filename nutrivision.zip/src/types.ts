export interface NutritionFacts {
  calories: number; // kcal
  protein: number; // g
  carbohydrates: number; // g
  fat: number; // g
  fiber: number; // g
  sugar: number; // g
  sodium: number; // mg
  cholesterol: number; // mg
  potassium: number; // mg
  calcium: number; // mg
  iron: number; // mg
  vitaminA: number; // mcg / IU
  vitaminC: number; // mg
  vitaminD: number; // mcg
  vitaminB12: number; // mcg
  magnesium: number; // mg
  zinc: number; // mg
}

export interface DietBadges {
  vegetarian: boolean;
  vegan: boolean;
  glutenFree: boolean;
  ketoFriendly: boolean;
  highProtein: boolean;
  lowCarb: boolean;
  diabeticFriendly: boolean;
}

export interface DietRecommendation {
  healthRating: number; // 0 to 10 scale or 0-100
  benefits: string[];
  drawbacks: string[];
  recommendedPortionSize: string;
  bestTimeToEat: string;
  weightLossAdvice: string;
  weightGainAdvice: string;
  muscleBuildingAdvice: string;
  diabetesAdvice: string;
  heartHealthAdvice: string;
  healthierAlternatives: string[];
}

export interface FoodItem {
  id: string;
  name: string;
  category: 'South Indian' | 'North Indian' | 'Desserts' | 'Continental & Fast Food' | 'Healthy Foods' | 'Other';
  servingSize: string;
  image?: string;
  description?: string;
  nutrition: NutritionFacts;
  healthScore: number; // 1-100
  glycemicIndex: number; // low (<55), medium (56-69), high (70+)
  dietBadges: DietBadges;
  recommendation: DietRecommendation;
}

export interface LoggedMeal {
  id: string;
  foodName: string;
  mealType: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks';
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  serving: string;
  timestamp: string;
  date: string; // YYYY-MM-DD
}

export interface UserGoals {
  dailyCalories: number;
  dailyProtein: number; // g
  dailyCarbs: number; // g
  dailyFat: number; // g
  dailyWater: number; // liters
  targetWeight: number; // kg
  currentWeight: number; // kg
  dietaryPreference: 'None' | 'Vegetarian' | 'Vegan' | 'Keto' | 'High Protein' | 'Low Carb';
  allergies: string[];
}

export interface UserProfile {
  uid?: string;
  name: string;
  email: string;
  avatar?: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  height: number; // cm
  weight: number; // kg
  activityLevel: 'Sedentary' | 'Lightly Active' | 'Moderately Active' | 'Very Active' | 'Extra Active';
  goals: UserGoals;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  category: string;
  prepTime: string;
  cookTime: string;
  servings: number;
  caloriesPerServing: number;
  protein: number;
  carbs: number;
  fat: number;
  ingredients: string[];
  instructions: string[];
  dietaryCategory: 'Weight Loss' | 'Weight Gain' | 'Muscle Building' | 'Vegetarian' | 'Vegan' | 'Diabetic';
  healthScore: number;
  image?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  suggestedAction?: string;
}
