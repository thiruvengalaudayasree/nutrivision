import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { HeroSection } from './components/HeroSection';
import { FoodAnalyzer } from './components/FoodAnalyzer';
import { FoodDatabaseView } from './components/FoodDatabaseView';
import { DietRecommendationView } from './components/DietRecommendationView';
import { WaterCalculator } from './components/WaterCalculator';
import { BmiCalculator } from './components/BmiCalculator';
import { MealTracker } from './components/MealTracker';
import { RecipeGenerator } from './components/RecipeGenerator';
import { ChatbotView } from './components/ChatbotView';
import { DashboardView } from './components/DashboardView';
import { SettingsView } from './components/SettingsView';
import { AuthModal } from './components/AuthModal';
import { Footer } from './components/Footer';
import { UserProfile, LoggedMeal } from './types';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);

  // User profile state
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('nutrivision_user');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return null; }
    }
    return {
      uid: 'user-demo-1',
      name: 'NVIDIA Scholar',
      email: 'alex@example.com',
      age: 27,
      gender: 'female',
      height: 178,
      weight: 71,
      targetCalories: 2200,
      targetProtein: 120,
      targetWaterLiters: 2.5,
      dietaryPreference: 'Non-Vegetarian',
    };
  });

  // Logged meals state
  const [loggedMeals, setLoggedMeals] = useState<LoggedMeal[]>(() => {
    const saved = localStorage.getItem('nutrivision_meals');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return []; }
    }
    return [
      {
        id: 'm-1',
        foodName: 'Chicken Biryani',
        mealType: 'Lunch',
        calories: 548,
        protein: 34,
        carbs: 68,
        fat: 16,
        serving: '1 bowl (300g)',
        timestamp: new Date().toISOString(),
        date: new Date().toISOString().split('T')[0],
      },
      {
        id: 'm-2',
        foodName: 'Masala Dosa with Chutney',
        mealType: 'Breakfast',
        calories: 320,
        protein: 7.5,
        carbs: 52,
        fat: 10.5,
        serving: '1 dosa (150g)',
        timestamp: new Date().toISOString(),
        date: new Date().toISOString().split('T')[0],
      }
    ];
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('nutrivision_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('nutrivision_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('nutrivision_meals', JSON.stringify(loggedMeals));
  }, [loggedMeals]);

  const handleAddMeal = (mealData: Omit<LoggedMeal, 'id' | 'timestamp'>) => {
    const newMeal: LoggedMeal = {
      ...mealData,
      id: 'meal-' + Date.now(),
      timestamp: new Date().toISOString(),
    };
    setLoggedMeals(prev => [newMeal, ...prev]);
  };

  const handleRemoveMeal = (id: string) => {
    setLoggedMeals(prev => prev.filter(m => m.id !== id));
  };

  const handleClearMeals = () => {
    if (confirm('Are you sure you want to clear today\'s meal logs?')) {
      setLoggedMeals([]);
    }
  };

  const handleSelectFoodToAnalyzeFromDB = (foodName: string) => {
    setActiveTab('analyzer');
  };

  return (
    <div className="min-h-screen bg-[#FFF5F7] text-[#2D2D2D] font-sans flex flex-col lg:flex-row selection:bg-pink-200 selection:text-rose-900">
      
      {/* Sidebar for Desktop */}
      <div className="hidden lg:block">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          user={user}
          loggedMeals={loggedMeals}
          onOpenAuth={() => setIsAuthOpen(true)}
          onLogout={() => setUser(null)}
        />
      </div>

      {/* Top Navbar for Mobile/Tablet */}
      <div className="lg:hidden w-full">
        <Navbar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          user={user}
          onOpenAuth={() => setIsAuthOpen(true)}
          onLogout={() => setUser(null)}
        />
      </div>

      {/* Main Content Render */}
      <div className="flex-1 flex flex-col min-w-0">
        <main className="flex-1">
          {activeTab === 'dashboard' && (
            <DashboardView
              user={user}
              loggedMeals={loggedMeals}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'home' && (
            <div className="space-y-12">
              <HeroSection
                onStartAnalyze={() => setActiveTab('analyzer')}
                onExploreDB={() => setActiveTab('database')}
                onOpenWater={() => setActiveTab('water')}
              />
              <FoodAnalyzer onLogMeal={handleAddMeal} />
            </div>
          )}

          {activeTab === 'analyzer' && (
            <FoodAnalyzer onLogMeal={handleAddMeal} />
          )}

          {activeTab === 'database' && (
            <FoodDatabaseView onSelectFoodToAnalyze={handleSelectFoodToAnalyzeFromDB} />
          )}

          {activeTab === 'recommendation' && (
            <DietRecommendationView />
          )}

          {activeTab === 'water' && (
            <WaterCalculator user={user} />
          )}

          {activeTab === 'bmi' && (
            <BmiCalculator user={user} />
          )}

          {activeTab === 'tracker' && (
            <MealTracker
              loggedMeals={loggedMeals}
              onAddMeal={handleAddMeal}
              onRemoveMeal={handleRemoveMeal}
              onClearAll={handleClearMeals}
            />
          )}

          {activeTab === 'recipes' && (
            <RecipeGenerator />
          )}

          {activeTab === 'chatbot' && (
            <ChatbotView />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              user={user}
              onSaveUser={(updated) => setUser(updated)}
            />
          )}
        </main>

        {/* Footer */}
        <Footer onNavigate={setActiveTab} />
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={(loggedUser) => setUser(loggedUser)}
      />

    </div>
  );
}

export default App;
