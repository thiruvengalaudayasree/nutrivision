import React from 'react';
import { 
  Sparkles, 
  Search, 
  Camera, 
  Heart, 
  ShieldCheck, 
  Zap, 
  Droplets, 
  Bot, 
  Award,
  ChevronRight,
  TrendingUp,
  Apple
} from 'lucide-react';

interface HeroSectionProps {
  onStartAnalyze: () => void;
  onExploreDB: () => void;
  onOpenWater: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartAnalyze,
  onExploreDB,
  onOpenWater,
}) => {
  return (
    <section className="relative overflow-hidden bg-[#FFF5F7] py-12 lg:py-20 border-b border-pink-100">
      
      {/* Decorative Light Background Accents */}
      <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 rounded-full bg-rose-200/40 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-80 h-80 rounded-full bg-pink-300/30 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Text Content */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Capstone Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-rose-200 shadow-sm text-xs font-semibold text-rose-800 animate-fadeIn">
              <Award className="w-4 h-4 text-emerald-600" />
              <span>NVIDIA Capstone Project</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-slate-500">Multimodal Gemini AI</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 leading-[1.1] tracking-tight">
              Transform Your Health with <span className="bg-gradient-to-r from-rose-500 via-pink-600 to-rose-700 bg-clip-text text-transparent">AI-Powered</span> Nutrition
            </h1>

            <p className="text-base sm:text-lg text-slate-700 max-w-2xl leading-relaxed">
              NutriVision brings real-time computer vision and multimodal Gemini AI to identify foods, accurately measure macros & micronutrients, and provide customized clinical diet recommendations.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onStartAnalyze}
                className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-rose-500 text-white font-bold text-sm hover:bg-rose-600 shadow-lg shadow-rose-200 transition-all hover:scale-[1.02] active:scale-95"
              >
                <Search className="w-4 h-4" />
                Analyze Food Now
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreDB}
                className="flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-white text-slate-800 font-semibold text-sm hover:bg-pink-50 border border-pink-200 shadow-sm transition-all"
              >
                <Apple className="w-4 h-4 text-rose-500" />
                Browse Smart Food DB
              </button>

              <button
                onClick={onOpenWater}
                className="flex items-center gap-2 px-4 py-3.5 rounded-2xl bg-sky-50 text-sky-800 font-semibold text-sm hover:bg-sky-100 border border-sky-200 transition-all"
              >
                <Droplets className="w-4 h-4 text-sky-600" />
                Water Tracker
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-rose-200/60 max-w-xl">
              <div>
                <p className="text-2xl font-black text-slate-900">17+</p>
                <p className="text-xs font-semibold text-slate-600">Macro & Micronutrients</p>
              </div>
              <div>
                <p className="text-2xl font-black text-rose-600">100%</p>
                <p className="text-xs font-semibold text-slate-600">Realistic Custom Profiles</p>
              </div>
              <div>
                <p className="text-2xl font-black text-emerald-600">Gemini 3.6</p>
                <p className="text-xs font-semibold text-slate-600">Multimodal AI Engine</p>
              </div>
            </div>

          </div>

          {/* Right Visual Card Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md bg-white rounded-3xl p-6 shadow-xl border border-pink-100 space-y-5 animate-slideUp">
              
              {/* Header inside Showcase Card */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-600 font-bold">
                    🍗
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base">Grilled Chicken Fillet</h3>
                    <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-semibold border border-emerald-100">
                      Health Score: 96/100
                    </span>
                  </div>
                </div>
                <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
                  280 kcal
                </span>
              </div>

              {/* Progress Bars Showcase */}
              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between font-bold text-slate-800 mb-1">
                    <span>Protein (48g)</span>
                    <span className="text-rose-600">96% Goal</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-rose-500 h-full rounded-full w-[96%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-bold text-slate-800 mb-1">
                    <span>Carbohydrates (0g)</span>
                    <span className="text-slate-500">Low Carb</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-amber-400 h-full rounded-full w-[5%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-bold text-slate-800 mb-1">
                    <span>Healthy Fats (9.2g)</span>
                    <span className="text-emerald-600">Optimal</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full w-[35%]" />
                  </div>
                </div>
              </div>

              {/* Badges */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-1 rounded-lg">
                  High Protein
                </span>
                <span className="text-[11px] font-semibold bg-sky-50 text-sky-800 border border-sky-200 px-2.5 py-1 rounded-lg">
                  Keto Friendly
                </span>
                <span className="text-[11px] font-semibold bg-purple-50 text-purple-800 border border-purple-200 px-2.5 py-1 rounded-lg">
                  Diabetic Friendly
                </span>
              </div>

              {/* AI Recommendation Snippet */}
              <div className="p-3 bg-pink-50/80 rounded-2xl border border-pink-100 flex items-start gap-2.5 text-xs text-slate-800">
                <Sparkles className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                <p>
                  <strong>AI Diet Insight:</strong> Excellent lean protein choice for muscle synthesis with zero glycemic impact on blood glucose.
                </p>
              </div>

            </div>

            {/* Floating Pill */}
            <div className="absolute -bottom-4 -left-4 bg-slate-900 text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-semibold">
              <Camera className="w-4 h-4 text-rose-400" />
              <span>Snap & Auto-Analyze Food</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
