import React, { useState } from 'react';
import { User, Settings, Save, CheckCircle2 } from 'lucide-react';
import { UserProfile } from '../types';

interface SettingsViewProps {
  user: UserProfile | null;
  onSaveUser: (updatedUser: UserProfile) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ user, onSaveUser }) => {
  const [name, setName] = useState(user?.name || 'Jane Doe');
  const [email, setEmail] = useState(user?.email || 'jane@example.com');
  const [age, setAge] = useState<number>(user?.age || 26);
  const [height, setHeight] = useState<number>(user?.height || 168);
  const [weight, setWeight] = useState<number>(user?.weight || 62);
  const [targetCalories, setTargetCalories] = useState<number>(user?.targetCalories || 2100);
  const [targetProtein, setTargetProtein] = useState<number>(user?.targetProtein || 110);
  const [targetWaterLiters, setTargetWaterLiters] = useState<number>(user?.targetWaterLiters || 3.0);
  const [dietaryPreference, setDietaryPreference] = useState(user?.dietaryPreference || 'Non-Vegetarian');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      uid: user?.uid || 'user-1',
      name,
      email,
      age,
      gender: user?.gender || 'female',
      height,
      weight,
      targetCalories,
      targetProtein,
      targetWaterLiters,
      dietaryPreference,
    };

    onSaveUser(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Header */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">
          User Settings & Personal Goals
        </h2>
        <p className="text-xs text-slate-600">
          Customize your biometrics, target calories, protein goals, and dietary preferences.
        </p>
      </div>

      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-pink-100 space-y-6">
        
        {savedSuccess && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-bold flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Settings and personal target goals updated successfully!</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6 text-xs font-semibold text-slate-700">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
                required
              />
            </div>

            <div>
              <label className="block mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block mb-1">Age</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
              />
            </div>

            <div>
              <label className="block mb-1">Height (cm)</label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
              />
            </div>

            <div>
              <label className="block mb-1">Weight (kg)</label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block mb-1">Target Calories (kcal)</label>
              <input
                type="number"
                value={targetCalories}
                onChange={(e) => setTargetCalories(Number(e.target.value))}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
              />
            </div>

            <div>
              <label className="block mb-1">Target Protein (g)</label>
              <input
                type="number"
                value={targetProtein}
                onChange={(e) => setTargetProtein(Number(e.target.value))}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
              />
            </div>

            <div>
              <label className="block mb-1">Target Water (Liters)</label>
              <input
                type="number"
                step="0.1"
                value={targetWaterLiters}
                onChange={(e) => setTargetWaterLiters(Number(e.target.value))}
                className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl"
              />
            </div>
          </div>

          <div>
            <label className="block mb-1">Dietary Preference</label>
            <select
              value={dietaryPreference}
              onChange={(e) => setDietaryPreference(e.target.value)}
              className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl font-medium"
            >
              <option value="Vegetarian">Vegetarian</option>
              <option value="Vegan">Vegan</option>
              <option value="Non-Vegetarian">Non-Vegetarian</option>
              <option value="Keto">Keto</option>
              <option value="High Protein">High Protein</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-rose-500 hover:bg-rose-600 text-white font-extrabold text-sm rounded-2xl transition-all shadow-lg shadow-rose-200 flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Changes & Personal Goals
          </button>

        </form>

      </div>

    </div>
  );
};
