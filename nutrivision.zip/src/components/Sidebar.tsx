import React from 'react';
import { 
  HeartPulse, 
  Search, 
  Database, 
  Sparkles, 
  Droplets, 
  Activity, 
  UtensilsCrossed, 
  ChefHat, 
  MessageSquareText, 
  LayoutDashboard, 
  Settings,
  Flame,
  User,
  LogOut,
  Award
} from 'lucide-react';
import { UserProfile, LoggedMeal } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: UserProfile | null;
  loggedMeals: LoggedMeal[];
  onOpenAuth: () => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  user,
  loggedMeals,
  onOpenAuth,
  onLogout,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'home', label: 'Home Overview', icon: HeartPulse },
    { id: 'analyzer', label: 'Food Analyzer', icon: Search },
    { id: 'database', label: 'Nutrition DB', icon: Database },
    { id: 'recommendation', label: 'Diet Recommendations', icon: Sparkles },
    { id: 'water', label: 'Water Tracker', icon: Droplets },
    { id: 'bmi', label: 'BMI Tool', icon: Activity },
    { id: 'tracker', label: 'Meal Tracker', icon: UtensilsCrossed },
    { id: 'recipes', label: 'Recipes', icon: ChefHat },
    { id: 'chatbot', label: 'AI Chatbot', icon: MessageSquareText },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const targetCalories = user?.targetCalories || 2200;
  const currentCalories = loggedMeals.reduce((acc, m) => acc + m.calories, 0);
  const percentGoal = Math.min(100, Math.round((currentCalories / targetCalories) * 100));

  return (
    <aside className="w-64 bg-white border-r border-[#F8BBD0] flex flex-col h-screen sticky top-0 shrink-0 select-none">
      
      {/* Brand Header */}
      <div 
        onClick={() => setActiveTab('dashboard')}
        className="p-6 flex items-center gap-3 cursor-pointer group"
      >
        <div className="w-10 h-10 bg-[#F8BBD0] rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
          <div className="w-4 h-4 bg-white rounded-full flex items-center justify-center">
            <div className="w-1.5 h-1.5 bg-[#F8BBD0] rounded-full" />
          </div>
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#2D2D2D] font-display">NutriVision</h1>
          <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest block">AI Nutrition</span>
        </div>
      </div>

      {/* Navigation Items */}
      <nav className="flex-1 px-3 space-y-1.5 overflow-y-auto pt-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all text-left ${
                isActive
                  ? 'bg-[#FFF5F7] text-[#2D2D2D] border border-[#F8BBD0] shadow-xs'
                  : 'text-slate-600 hover:bg-gray-50 hover:text-slate-900'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-[#F8BBD0]' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Daily Goal Card Accent */}
      <div className="m-3 p-4 bg-[#F8BBD0] bg-opacity-20 rounded-2xl border border-[#F8BBD0] space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold uppercase tracking-wider text-rose-700">Daily Goal</p>
          <Flame className="w-3.5 h-3.5 text-rose-500" />
        </div>
        <div className="flex justify-between items-end">
          <span className="text-xl font-extrabold text-[#2D2D2D]">{currentCalories.toLocaleString()}</span>
          <span className="text-xs text-slate-500 font-medium">/ {targetCalories.toLocaleString()} kcal</span>
        </div>
        <div className="w-full bg-white h-2 rounded-full overflow-hidden border border-rose-100">
          <div 
            className="bg-[#F8BBD0] h-full transition-all duration-500 rounded-full" 
            style={{ width: `${percentGoal || 10}%` }} 
          />
        </div>
      </div>

      {/* User Footer Profile */}
      <div className="p-4 border-t border-gray-100 flex items-center justify-between gap-3 bg-slate-50/50">
        {user ? (
          <>
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-9 h-9 rounded-full bg-rose-400 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm">
                {user.name ? user.name[0].toUpperCase() : 'U'}
              </div>
              <div className="truncate">
                <p className="text-xs font-bold text-[#2D2D2D] truncate">{user.name}</p>
                <p className="text-[9px] text-emerald-600 font-extrabold uppercase tracking-wider">NVIDIA Scholar</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              title="Logout"
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </>
        ) : (
          <button
            onClick={onOpenAuth}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl bg-[#2D2D2D] text-white text-xs font-bold hover:bg-slate-800 transition-all shadow-sm"
          >
            <User className="w-3.5 h-3.5" />
            Sign In / Register
          </button>
        )}
      </div>

    </aside>
  );
};
