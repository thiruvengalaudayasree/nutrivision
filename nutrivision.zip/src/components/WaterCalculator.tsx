import React, { useState } from 'react';
import { 
  Droplets, 
  Plus, 
  Minus, 
  RotateCcw, 
  CheckCircle2, 
  Flame, 
  Award,
  Zap,
  Bell,
  Sun
} from 'lucide-react';
import { UserProfile } from '../types';

interface WaterCalculatorProps {
  user: UserProfile | null;
}

export const WaterCalculator: React.FC<WaterCalculatorProps> = ({ user }) => {
  // Calculator Form State
  const [weight, setWeight] = useState<number>(user?.weight || 70);
  const [height, setHeight] = useState<number>(user?.height || 170);
  const [age, setAge] = useState<number>(user?.age || 25);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [activity, setActivity] = useState<string>('Moderate');
  const [climate, setClimate] = useState<string>('Normal');

  // Glass Tracker State
  const [consumedMl, setConsumedMl] = useState<number>(1250); // initial 5 glasses
  const glassSize = 250; // 250ml per glass

  // Calculate Target Water Requirement
  const calculateTargetLiters = (): number => {
    // Base formula: 35ml per kg body weight
    let base = weight * 0.035;

    // Activity multiplier
    if (activity === 'Active') base += 0.5;
    if (activity === 'Extreme') base += 1.0;

    // Climate multiplier
    if (climate === 'Hot / Humid') base += 0.5;

    // Gender tweak
    if (gender === 'male') base += 0.2;

    return Math.round(base * 10) / 10;
  };

  const targetLiters = calculateTargetLiters();
  const targetMl = targetLiters * 1000;
  const targetGlasses = Math.ceil(targetMl / glassSize);
  const currentGlasses = Math.floor(consumedMl / glassSize);
  const percentage = Math.min(100, Math.round((consumedMl / targetMl) * 100));

  const addGlass = () => {
    setConsumedMl(prev => prev + glassSize);
  };

  const removeGlass = () => {
    setConsumedMl(prev => Math.max(0, prev - glassSize));
  };

  const resetTracker = () => {
    setConsumedMl(0);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-sky-600 bg-sky-100 px-3 py-1 rounded-full border border-sky-200">
          Precision Hydration Engine
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          AI Water Intake Calculator & Hydration Tracker
        </h2>
        <p className="text-slate-600 text-sm sm:text-base">
          Calculate your personalized daily hydration requirement based on weight, climate, and metabolic activity, and log your glasses throughout the day.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Calculator Inputs */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 shadow-md border border-sky-100 space-y-5">
          <h3 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <Droplets className="w-5 h-5 text-sky-500" />
            Hydration Parameters
          </h3>

          <div className="space-y-4 text-xs font-semibold text-slate-700">
            <div>
              <label className="block mb-1">Body Weight (kg): {weight} kg</label>
              <input
                type="range"
                min="30"
                max="150"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block mb-1">Height (cm)</label>
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-full p-2.5 bg-sky-50/50 border border-sky-200 rounded-xl"
                />
              </div>
              <div>
                <label className="block mb-1">Age (years)</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full p-2.5 bg-sky-50/50 border border-sky-200 rounded-xl"
                />
              </div>
            </div>

            <div>
              <label className="block mb-1">Gender</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setGender('male')}
                  className={`py-2 rounded-xl border text-xs font-bold transition-all ${
                    gender === 'male' ? 'bg-sky-500 text-white border-sky-500' : 'bg-slate-50 text-slate-700'
                  }`}
                >
                  Male
                </button>
                <button
                  onClick={() => setGender('female')}
                  className={`py-2 rounded-xl border text-xs font-bold transition-all ${
                    gender === 'female' ? 'bg-sky-500 text-white border-sky-500' : 'bg-slate-50 text-slate-700'
                  }`}
                >
                  Female
                </button>
              </div>
            </div>

            <div>
              <label className="block mb-1">Activity Level</label>
              <select
                value={activity}
                onChange={(e) => setActivity(e.target.value)}
                className="w-full p-2.5 bg-sky-50/50 border border-sky-200 rounded-xl font-medium"
              >
                <option value="Sedentary">Sedentary (Desk Job)</option>
                <option value="Moderate">Moderate (Light Exercise)</option>
                <option value="Active">Active (1-2 hr Workout)</option>
                <option value="Extreme">Extreme (Heavy Athletics)</option>
              </select>
            </div>

            <div>
              <label className="block mb-1">Local Climate</label>
              <select
                value={climate}
                onChange={(e) => setClimate(e.target.value)}
                className="w-full p-2.5 bg-sky-50/50 border border-sky-200 rounded-xl font-medium"
              >
                <option value="Normal">Normal / Air Conditioned</option>
                <option value="Hot / Humid">Hot / Humid / Summer</option>
              </select>
            </div>

          </div>

          <div className="p-4 bg-sky-50 rounded-2xl border border-sky-200 text-center space-y-1">
            <span className="text-xs font-bold text-sky-800 uppercase block">Calculated Daily Target</span>
            <p className="text-3xl font-black text-sky-600">{targetLiters} Liters</p>
            <span className="text-xs text-sky-700 font-semibold">({targetGlasses} standard 250ml glasses)</span>
          </div>

        </div>

        {/* Right Column: Interactive Glass Tracker & Fill Animation */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-sky-100 space-y-6">
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-black text-slate-900">Today's Hydration Progress</h3>
              <p className="text-xs text-slate-500">Track standard 250ml glasses consumed today</p>
            </div>
            <button
              onClick={resetTracker}
              className="p-2 text-xs font-semibold text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
          </div>

          {/* Dynamic Fill Container */}
          <div className="relative bg-sky-50 border-2 border-sky-200 rounded-3xl p-6 overflow-hidden flex flex-col items-center justify-center min-h-[220px]">
            
            {/* Animated Water Background Level */}
            <div 
              className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-sky-400 to-sky-300 transition-all duration-500 opacity-80"
              style={{ height: `${percentage}%` }}
            />

            {/* Content Over Water */}
            <div className="relative z-10 text-center space-y-2">
              <span className="text-5xl font-black text-slate-900 drop-shadow-sm">{percentage}%</span>
              <p className="text-sm font-extrabold text-slate-800">
                {consumedMl} ml / {targetMl} ml
              </p>
              <p className="text-xs font-bold text-sky-900 bg-white/80 px-3 py-1 rounded-full shadow-sm inline-block">
                {currentGlasses} of {targetGlasses} Glasses
              </p>
            </div>

          </div>

          {/* Quick Glass Add/Subtract Buttons */}
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={removeGlass}
              disabled={consumedMl <= 0}
              className="p-4 rounded-2xl bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 font-bold transition-all shadow-sm"
            >
              <Minus className="w-6 h-6" />
            </button>

            <button
              onClick={addGlass}
              className="flex-1 max-w-xs py-4 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-extrabold text-sm transition-all shadow-lg shadow-sky-200 flex items-center justify-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Drink 1 Glass (+250ml)
            </button>
          </div>

          {/* Glass Grid View */}
          <div className="space-y-2 pt-4 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-700 block">Glass Milestones:</span>
            <div className="grid grid-cols-6 sm:grid-cols-10 gap-2">
              {Array.from({ length: targetGlasses }).map((_, idx) => {
                const filled = idx < currentGlasses;
                return (
                  <div
                    key={idx}
                    onClick={() => setConsumedMl((idx + 1) * glassSize)}
                    className={`aspect-square rounded-xl flex items-center justify-center cursor-pointer transition-all ${
                      filled
                        ? 'bg-sky-500 text-white shadow-md scale-105'
                        : 'bg-slate-100 text-slate-400 hover:bg-sky-100'
                    }`}
                  >
                    <Droplets className="w-4 h-4" />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Hydration Tips */}
          <div className="p-4 bg-sky-50/50 rounded-2xl border border-sky-100 text-xs text-slate-700 space-y-1">
            <span className="font-extrabold text-sky-900 block flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-sky-600" /> Clinical Hydration Tip
            </span>
            <p>
              Drinking a glass of water 30 minutes before meals aids enzymatic digestion and regulates appetite control effectively.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
