import React, { useState } from 'react';
import { 
  Activity, 
  Info, 
  TrendingDown, 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle,
  Dumbbell,
  Heart
} from 'lucide-react';
import { UserProfile } from '../types';

interface BmiCalculatorProps {
  user: UserProfile | null;
}

export const BmiCalculator: React.FC<BmiCalculatorProps> = ({ user }) => {
  const [heightCm, setHeightCm] = useState<number>(user?.height || 172);
  const [weightKg, setWeightKg] = useState<number>(user?.weight || 68);
  const [age, setAge] = useState<number>(user?.age || 26);
  const [gender, setGender] = useState<'male' | 'female'>('male');

  // BMI Formula: weight (kg) / (height (m) ^ 2)
  const heightM = heightCm / 100;
  const bmi = heightM > 0 ? Math.round((weightKg / (heightM * heightM)) * 10) / 10 : 0;

  // Category determination
  let category = 'Normal';
  let categoryColor = 'text-emerald-600';
  let categoryBg = 'bg-emerald-50 border-emerald-200';
  let pointerPercentage = 50;

  if (bmi < 18.5) {
    category = 'Underweight';
    categoryColor = 'text-amber-600';
    categoryBg = 'bg-amber-50 border-amber-200';
    pointerPercentage = Math.max(5, (bmi / 18.5) * 25);
  } else if (bmi >= 18.5 && bmi <= 24.9) {
    category = 'Normal / Healthy Weight';
    categoryColor = 'text-emerald-600';
    categoryBg = 'bg-emerald-50 border-emerald-200';
    pointerPercentage = 25 + ((bmi - 18.5) / 6.4) * 25;
  } else if (bmi >= 25 && bmi <= 29.9) {
    category = 'Overweight';
    categoryColor = 'text-orange-600';
    categoryBg = 'bg-orange-50 border-orange-200';
    pointerPercentage = 50 + ((bmi - 25) / 4.9) * 25;
  } else {
    category = 'Obese';
    categoryColor = 'text-rose-600';
    categoryBg = 'bg-rose-50 border-rose-200';
    pointerPercentage = Math.min(95, 75 + ((bmi - 30) / 10) * 25);
  }

  // Ideal weight range for height
  const minIdealWeight = Math.round(18.5 * (heightM * heightM));
  const maxIdealWeight = Math.round(24.9 * (heightM * heightM));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-200">
          Clinical Body Composition
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          BMI & Healthy Weight Calculator
        </h2>
        <p className="text-slate-600 text-sm sm:text-base">
          Evaluate your Body Mass Index (BMI), identify your optimal weight spectrum, and receive customized clinical fitness guidance.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Inputs */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 shadow-md border border-pink-100 space-y-5">
          <h3 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-500" />
            Biometric Inputs
          </h3>

          <div className="space-y-4 text-xs font-semibold text-slate-700">
            <div>
              <div className="flex justify-between mb-1">
                <span>Height: {heightCm} cm</span>
                <span className="text-slate-400">({Math.floor(heightCm / 30.48)}' {Math.round((heightCm % 30.48) / 2.54)}")</span>
              </div>
              <input
                type="range"
                min="120"
                max="220"
                value={heightCm}
                onChange={(e) => setHeightCm(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span>Weight: {weightKg} kg</span>
                <span className="text-slate-400">({Math.round(weightKg * 2.205)} lbs)</span>
              </div>
              <input
                type="range"
                min="30"
                max="180"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block mb-1">Age</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full p-2.5 bg-pink-50/40 border border-pink-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block mb-1">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full p-2.5 bg-pink-50/40 border border-pink-200 rounded-xl font-medium"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
            </div>

          </div>

          <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 text-center space-y-1">
            <span className="text-xs font-bold text-emerald-800 uppercase block">Healthy Weight Range for {heightCm} cm</span>
            <p className="text-xl font-black text-emerald-700">{minIdealWeight} kg – {maxIdealWeight} kg</p>
          </div>

        </div>

        {/* Right Output & Gauge */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-pink-100 space-y-6">
          
          <div className="text-center space-y-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Your Calculated BMI</span>
            <span className="text-5xl font-black text-slate-900">{bmi}</span>
            <div className={`inline-block px-4 py-1.5 rounded-full border text-xs font-extrabold ${categoryBg} ${categoryColor}`}>
              {category}
            </div>
          </div>

          {/* Visual BMI Pointer Scale */}
          <div className="space-y-2">
            <div className="relative h-4 rounded-full bg-gradient-to-r from-amber-400 via-emerald-500 via-orange-400 to-rose-500 overflow-hidden shadow-inner" />
            
            {/* Pointer Indicator */}
            <div className="relative h-6">
              <div 
                className="absolute top-0 -translate-x-1/2 flex flex-col items-center transition-all duration-300"
                style={{ left: `${pointerPercentage}%` }}
              >
                <div className="w-3 h-3 bg-slate-900 rotate-45" />
                <span className="text-[10px] font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded shadow mt-1">
                  {bmi}
                </span>
              </div>
            </div>

            <div className="flex justify-between text-[10px] font-bold text-slate-400 pt-1">
              <span>Underweight (&lt;18.5)</span>
              <span>Normal (18.5-24.9)</span>
              <span>Overweight (25-29.9)</span>
              <span>Obese (30+)</span>
            </div>
          </div>

          {/* Specific Advice Card */}
          <div className="p-5 bg-pink-50/40 rounded-2xl border border-pink-100 space-y-3 text-xs">
            <h4 className="font-extrabold text-slate-900 flex items-center gap-2 text-sm">
              <Heart className="w-4 h-4 text-rose-500" /> Personalized Health Strategy
            </h4>

            {bmi < 18.5 && (
              <p className="text-slate-700 leading-relaxed">
                You are currently below the standard recommended weight range. Focus on nutrient-dense complex foods with higher healthy fats and protein to support lean mass.
              </p>
            )}

            {bmi >= 18.5 && bmi <= 24.9 && (
              <p className="text-slate-700 leading-relaxed">
                Excellent! Your BMI falls in the ideal healthy spectrum. Maintain this balance with consistent hydration, balanced macronutrients, and active physical training.
              </p>
            )}

            {bmi >= 25 && bmi <= 29.9 && (
              <p className="text-slate-700 leading-relaxed">
                Your BMI is slightly elevated. A moderate caloric reduction of 300-500 kcal daily paired with daily cardiovascular activity can gently optimize body composition.
              </p>
            )}

            {bmi >= 30 && (
              <p className="text-slate-700 leading-relaxed">
                A structured weight management plan is recommended. Prioritize whole foods, high fiber intake, water intake, and consult a medical or clinical dietary expert.
              </p>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};
