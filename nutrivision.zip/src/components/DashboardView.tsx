import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { 
  Flame, 
  Dumbbell, 
  Droplets, 
  TrendingUp, 
  Award, 
  Calendar, 
  ChevronRight,
  Activity,
  Wheat,
  Droplet,
  Camera,
  Plus,
  Sparkles,
  Send,
  Heart
} from 'lucide-react';
import { UserProfile, LoggedMeal } from '../types';

interface DashboardViewProps {
  user: UserProfile | null;
  loggedMeals: LoggedMeal[];
  onNavigate: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  loggedMeals,
  onNavigate,
}) => {
  const targetCalories = user?.targetCalories || 2200;
  const targetProtein = user?.targetProtein || 120;
  const targetWaterLiters = user?.targetWaterLiters || 2.5;

  // Calculate current totals
  const currentCalories = loggedMeals.reduce((acc, m) => acc + m.calories, 0);
  const currentProtein = loggedMeals.reduce((acc, m) => acc + m.protein, 0);
  const currentCarbs = loggedMeals.reduce((acc, m) => acc + m.carbs, 0);
  const currentFat = loggedMeals.reduce((acc, m) => acc + m.fat, 0);

  // Quick water intake state
  const [waterAmount, setWaterAmount] = useState<number>(1.8);

  // Chatbot quick widget state
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState([
    { id: 1, sender: 'bot', text: 'Hi Alex! I see you logged Chicken Biryani today. Want a low-carb alternative for dinner?' },
    { id: 2, sender: 'user', text: 'Yes, something high protein please.' },
    { id: 3, sender: 'bot', text: 'How about Pan-Seared Salmon with Asparagus? Only 320 kcal and 38g protein!' },
  ]);

  const handleSendQuickChat = (textToSend?: string) => {
    const text = textToSend || chatInput;
    if (!text.trim()) return;

    setChatHistory(prev => [
      ...prev,
      { id: Date.now(), sender: 'user', text },
      { 
        id: Date.now() + 1, 
        sender: 'bot', 
        text: `Great choice! I've noted your preference for "${text}". Your macros are automatically balancing for today's target.` 
      }
    ]);
    if (!textToSend) setChatInput('');
  };

  const todayDateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      
      {/* Top Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#F8BBD0] bg-rose-50 px-2.5 py-0.5 rounded-full border border-[#F8BBD0]/40">
              NVIDIA AI Telemetry
            </span>
            <span className="text-xs text-slate-400 font-semibold">• {todayDateStr}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#2D2D2D] tracking-tight">
            Welcome back, {user?.name || 'Alex'}!
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Your AI-powered health overview and multimodal nutrition breakdown.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={() => onNavigate('analyzer')}
            className="px-4 py-2.5 bg-white text-slate-800 rounded-full shadow-sm border border-[#F8BBD0] hover:bg-pink-50 transition-all flex items-center gap-2 text-xs font-bold"
          >
            <Camera className="w-4 h-4 text-rose-500" />
            <span>AI Scan</span>
          </button>
          <button 
            onClick={() => onNavigate('tracker')}
            className="px-4 py-2.5 bg-[#4CAF50] hover:bg-green-600 text-white rounded-full shadow-md flex items-center gap-2 text-xs font-bold transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Log Meal</span>
          </button>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Protein Stat */}
        <div className="bg-white p-5 rounded-3xl shadow-xs border border-pink-100/80 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Protein</p>
            <Dumbbell className="w-4 h-4 text-rose-500" />
          </div>
          <div className="flex items-center gap-3">
            <div className="text-2xl font-extrabold text-[#2D2D2D]">{currentProtein.toFixed(0)}g</div>
            <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="bg-[#F8BBD0] h-full rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(100, (currentProtein / targetProtein) * 100)}%` }} 
              />
            </div>
          </div>
          <span className="text-[10px] text-slate-400 font-semibold block">Goal: {targetProtein}g</span>
        </div>

        {/* Carbs Stat */}
        <div className="bg-white p-5 rounded-3xl shadow-xs border border-pink-100/80 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Carbs</p>
            <Wheat className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-center gap-3">
            <div className="text-2xl font-extrabold text-[#2D2D2D]">{currentCarbs.toFixed(0)}g</div>
            <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="bg-emerald-400 h-full rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(100, (currentCarbs / 250) * 100)}%` }} 
              />
            </div>
          </div>
          <span className="text-[10px] text-slate-400 font-semibold block">Target: ~220g</span>
        </div>

        {/* Fats Stat */}
        <div className="bg-white p-5 rounded-3xl shadow-xs border border-pink-100/80 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fats</p>
            <Droplet className="w-4 h-4 text-orange-400" />
          </div>
          <div className="flex items-center gap-3">
            <div className="text-2xl font-extrabold text-[#2D2D2D]">{currentFat.toFixed(0)}g</div>
            <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="bg-orange-300 h-full rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(100, (currentFat / 65) * 100)}%` }} 
              />
            </div>
          </div>
          <span className="text-[10px] text-slate-400 font-semibold block">Target: ~60g</span>
        </div>

        {/* Health Score Stat */}
        <div className="bg-white p-5 rounded-3xl shadow-xs border border-pink-100/80 space-y-2">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Health Score</p>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-extrabold text-[#4CAF50]">94</span>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
              Optimal Spectrum
            </span>
          </div>
          <span className="text-[10px] text-slate-400 font-semibold block">Based on glycemic & macro index</span>
        </div>

      </div>

      {/* Main Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column (AI Focus Card & Metric Widgets) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* AI Analyzer Focus Card */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-[#F8BBD0] border-opacity-40 relative overflow-hidden">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-extrabold rounded uppercase tracking-widest">
                Recent AI Analysis
              </span>
              <span className="text-xs text-slate-400 font-semibold">• Today's Featured Scan</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 items-start">
              <div className="w-full sm:w-44 h-44 bg-[#FFF5F7] rounded-2xl flex flex-col items-center justify-center border-2 border-dashed border-[#F8BBD0] shrink-0 p-4 text-center">
                <span className="text-5xl mb-2">🍛</span>
                <span className="text-xs font-bold text-slate-800">Chicken Biryani</span>
                <span className="text-[10px] text-slate-500">1 bowl (300g)</span>
              </div>

              <div className="flex-1 space-y-3">
                <div>
                  <h3 className="text-2xl font-black text-[#2D2D2D]">Chicken Biryani</h3>
                  <p className="text-xs text-slate-500">
                    NVIDIA Multimodal AI Estimate: High Protein, Traditional Spice Blend
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                    <span className="block text-[10px] text-slate-400 uppercase font-bold">Calories</span>
                    <span className="text-lg font-black text-slate-900">548 kcal</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                    <span className="block text-[10px] text-slate-400 uppercase font-bold">Glycemic Index</span>
                    <span className="text-lg font-black text-slate-900">Moderate (55)</span>
                  </div>
                </div>

                {/* Green Highlighted AI Insight Box */}
                <div className="p-3.5 border-l-4 border-[#4CAF50] bg-green-50/80 rounded-r-2xl space-y-1">
                  <p className="text-xs font-bold text-green-800 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#4CAF50]" /> AI Clinical Insight
                  </p>
                  <p className="text-xs text-green-700 leading-relaxed italic">
                    "Good for muscle recovery with 34g protein, but monitor sodium. Pairing with yogurt (raita) improves digestion and gut health."
                  </p>
                </div>

              </div>
            </div>
          </div>

          {/* Quick Widgets Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            
            {/* Water Tracker Card */}
            <div className="bg-white rounded-3xl p-5 shadow-xs border border-pink-100 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="text-blue-400">💧</span> Water Hydration
                </h4>
                <span className="text-xs font-bold text-blue-600">{waterAmount.toFixed(1)}L / {targetWaterLiters}L</span>
              </div>

              <div className="w-full h-3 bg-[#FFF5F7] rounded-full overflow-hidden border border-blue-100">
                <div 
                  className="bg-sky-400 h-full rounded-full transition-all duration-300" 
                  style={{ width: `${Math.min(100, (waterAmount / targetWaterLiters) * 100)}%` }} 
                />
              </div>

              <div className="flex justify-between items-center pt-1">
                <div className="flex gap-1.5">
                  <div className={`w-6 h-6 rounded-lg ${waterAmount >= 0.5 ? 'bg-sky-400 text-white' : 'bg-sky-50'} flex items-center justify-center text-[10px] font-bold`}>1</div>
                  <div className={`w-6 h-6 rounded-lg ${waterAmount >= 1.0 ? 'bg-sky-400 text-white' : 'bg-sky-50'} flex items-center justify-center text-[10px] font-bold`}>2</div>
                  <div className={`w-6 h-6 rounded-lg ${waterAmount >= 1.5 ? 'bg-sky-400 text-white' : 'bg-sky-50'} flex items-center justify-center text-[10px] font-bold`}>3</div>
                  <div className={`w-6 h-6 rounded-lg ${waterAmount >= 2.0 ? 'bg-sky-400 text-white' : 'bg-sky-50'} flex items-center justify-center text-[10px] font-bold`}>4</div>
                </div>

                <button 
                  onClick={() => setWaterAmount(prev => +(prev + 0.25).toFixed(1))}
                  className="text-[10px] font-extrabold text-sky-600 hover:text-sky-800 uppercase bg-sky-50 hover:bg-sky-100 px-3 py-1.5 rounded-xl border border-sky-200 transition-colors"
                >
                  Add Glass +
                </button>
              </div>
            </div>

            {/* BMI Metrics Card */}
            <div className="bg-white rounded-3xl p-5 shadow-xs border border-pink-100 space-y-3">
              <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <span className="text-orange-400">⚖️</span> BMI Metrics
              </h4>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-3xl font-black text-[#2D2D2D]">22.4</span>
                  <span className="block text-[10px] text-emerald-600 font-extrabold uppercase tracking-wide">
                    Normal Weight Range
                  </span>
                </div>
                <div className="text-right text-xs text-slate-500 font-medium">
                  Height: {user?.height || 178} cm<br/>
                  Weight: {user?.weight || 71} kg
                </div>
              </div>

              <button 
                onClick={() => onNavigate('bmi')}
                className="w-full py-1.5 text-center text-[10px] font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors"
              >
                Open Full BMI Calculator →
              </button>
            </div>

          </div>

        </div>

        {/* Right Assistant Sidebar (Dark Sleek Chat Container) */}
        <div className="lg:col-span-5 bg-[#2D2D2D] rounded-[36px] p-6 text-white flex flex-col shadow-2xl h-[540px] sticky top-6">
          
          <div className="flex items-center justify-between pb-4 border-b border-[#3D3D3D] mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-[#F8BBD0] to-[#4CAF50] p-0.5 flex items-center justify-center shadow-sm">
                <div className="w-full h-full bg-[#2D2D2D] rounded-[14px] flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-[#F8BBD0]" />
                </div>
              </div>
              <div>
                <p className="text-sm font-extrabold tracking-tight text-white">NutriVision AI Assistant</p>
                <span className="text-[9px] text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Gemini 3.6 Online
                </span>
              </div>
            </div>

            <button 
              onClick={() => onNavigate('chatbot')}
              className="text-[10px] font-bold text-[#F8BBD0] bg-[#3D3D3D] hover:bg-[#4D4D4D] px-2.5 py-1 rounded-xl transition-colors"
            >
              Expand Chat
            </button>
          </div>

          {/* Messages Flow */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs mb-4">
            {chatHistory.map((msg) => (
              <div
                key={msg.id}
                className={`p-3 rounded-2xl text-xs leading-relaxed max-w-[88%] ${
                  msg.sender === 'user'
                    ? 'bg-[#F8BBD0] bg-opacity-20 text-rose-100 rounded-tr-none ml-auto border border-[#F8BBD0]/30'
                    : 'bg-white bg-opacity-10 text-slate-100 rounded-tl-none mr-auto border border-white/10'
                }`}
              >
                {msg.text}
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="relative mb-3">
            <input 
              type="text" 
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendQuickChat()}
              placeholder="Ask about calories, meal plans..." 
              className="w-full bg-[#3D3D3D] rounded-2xl py-3 pl-4 pr-10 text-xs text-white border border-[#4D4D4D] focus:outline-none focus:border-[#F8BBD0]"
            />
            <button 
              onClick={() => handleSendQuickChat()}
              className="absolute right-3 top-2.5 text-[#F8BBD0] hover:scale-110 transition-transform"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>

          {/* Suggested Query Chips */}
          <div className="p-3 bg-[#3D3D3D]/60 rounded-2xl border border-[#4D4D4D]/50">
            <p className="text-[10px] uppercase font-bold text-gray-400 mb-2 tracking-wider">Suggested Queries</p>
            <div className="flex flex-wrap gap-1.5">
              {[
                "Post-workout meal?",
                "Vitamin D sources",
                "Keto dinner options",
              ].map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendQuickChat(q)}
                  className="bg-[#4D4D4D] hover:bg-[#5D5D5D] text-slate-200 px-2.5 py-1 rounded-xl text-[9px] font-bold transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};

