import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  TrendingDown, 
  TrendingUp, 
  Dumbbell, 
  Activity, 
  Heart, 
  Search,
  Scale
} from 'lucide-react';
import { BUILTIN_FOOD_DATABASE } from '../data/foodDatabase';
import { FoodItem } from '../types';
import { analyzeFoodItem } from '../services/api';

export const DietRecommendationView: React.FC = () => {
  const [selectedFood, setSelectedFood] = useState<FoodItem>(BUILTIN_FOOD_DATABASE[0]);
  const [customInput, setCustomInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearchCustom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;

    setLoading(true);
    try {
      const food = await analyzeFoodItem({ foodName: customInput.trim() });
      setSelectedFood(food);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-pink-600 bg-pink-100 px-3 py-1 rounded-full border border-pink-200">
          Personalized Clinical AI Insights
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          AI Diet & Health Recommendations
        </h2>
        <p className="text-slate-600 text-sm sm:text-base">
          Get specific dietary guidance tailored to your fitness goals, medical conditions, optimal meal timing, portion control, and heart health.
        </p>
      </div>

      {/* Food Selector & Custom Search */}
      <div className="max-w-3xl mx-auto bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-4">
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Select from Popular Dishes:</label>
            <select
              value={selectedFood.name}
              onChange={(e) => {
                const found = BUILTIN_FOOD_DATABASE.find(f => f.name === e.target.value);
                if (found) setSelectedFood(found);
              }}
              className="w-full p-3 bg-pink-50/50 border border-pink-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-400"
            >
              {BUILTIN_FOOD_DATABASE.map(food => (
                <option key={food.id} value={food.name}>
                  {food.name} ({food.category})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Or Enter Any Custom Food:</label>
            <form onSubmit={handleSearchCustom} className="flex gap-2">
              <input
                type="text"
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="e.g. Avocado Toast, Quinoa Salad..."
                className="w-full px-4 py-2.5 bg-pink-50/50 border border-pink-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
              <button
                type="submit"
                disabled={loading || !customInput.trim()}
                className="px-4 py-2.5 bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white text-xs font-bold rounded-2xl transition-colors shrink-0"
              >
                Analyze
              </button>
            </form>
          </div>
        </div>

      </div>

      {loading ? (
        <div className="text-center py-12">
          <Sparkles className="w-8 h-8 text-rose-500 animate-spin mx-auto mb-2" />
          <p className="text-sm font-bold text-slate-700">Generating AI Diet Recommendations...</p>
        </div>
      ) : (
        /* Selected Food Recommendation Display */
        <div className="space-y-6 animate-fadeIn">
          
          {/* Main Summary Header */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-pink-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <span className="text-xs font-bold text-pink-600 bg-pink-50 px-3 py-1 rounded-full border border-pink-200">
                {selectedFood.category}
              </span>
              <h3 className="text-3xl font-black text-slate-900 mt-2">{selectedFood.name}</h3>
              <p className="text-xs text-slate-600 mt-1 max-w-xl">{selectedFood.description}</p>
            </div>

            <div className="flex items-center gap-4 bg-rose-50 p-4 rounded-2xl border border-rose-100">
              <div className="text-center">
                <span className="text-xs font-bold text-rose-800 uppercase block">Health Rating</span>
                <span className="text-3xl font-black text-rose-600">{selectedFood.recommendation.healthRating}/10</span>
              </div>
              <div className="h-10 w-px bg-rose-200" />
              <div>
                <span className="text-xs font-bold text-slate-700 block">Portion Size:</span>
                <span className="text-xs font-semibold text-slate-900">{selectedFood.recommendation.recommendedPortionSize}</span>
              </div>
            </div>
          </div>

          {/* Benefits vs Drawbacks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-3">
              <h4 className="text-sm font-black text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Key Health Benefits
              </h4>
              <ul className="space-y-2 text-xs text-slate-700">
                {selectedFood.recommendation.benefits.map((benefit, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-3">
              <h4 className="text-sm font-black text-amber-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600" /> Dietary Drawbacks & Cautions
              </h4>
              <ul className="space-y-2 text-xs text-slate-700">
                {selectedFood.recommendation.drawbacks.map((drawback, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span>{drawback}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Specific Goal Matrix */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-2">
              <div className="flex items-center gap-2 text-rose-600 font-extrabold text-sm">
                <TrendingDown className="w-4 h-4" /> Weight Loss Strategy
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {selectedFood.recommendation.weightLossAdvice}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-2">
              <div className="flex items-center gap-2 text-emerald-600 font-extrabold text-sm">
                <TrendingUp className="w-4 h-4" /> Weight Gain Strategy
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {selectedFood.recommendation.weightGainAdvice}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-2">
              <div className="flex items-center gap-2 text-sky-600 font-extrabold text-sm">
                <Dumbbell className="w-4 h-4" /> Muscle Building Guidance
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {selectedFood.recommendation.muscleBuildingAdvice}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-2">
              <div className="flex items-center gap-2 text-purple-600 font-extrabold text-sm">
                <Activity className="w-4 h-4" /> Diabetes Management
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {selectedFood.recommendation.diabetesAdvice}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-2">
              <div className="flex items-center gap-2 text-red-600 font-extrabold text-sm">
                <Heart className="w-4 h-4" /> Heart & Blood Pressure
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {selectedFood.recommendation.heartHealthAdvice}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-2">
              <div className="flex items-center gap-2 text-indigo-600 font-extrabold text-sm">
                <Clock className="w-4 h-4" /> Best Time to Consume
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                {selectedFood.recommendation.bestTimeToEat}
              </p>
            </div>

          </div>

          {/* Alternatives */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-3">
            <h4 className="text-sm font-black text-slate-900">Healthier Alternative Recommendations:</h4>
            <div className="flex flex-wrap gap-2">
              {selectedFood.recommendation.healthierAlternatives.map((alt, i) => (
                <span key={i} className="px-3.5 py-1.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl">
                  {alt}
                </span>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
