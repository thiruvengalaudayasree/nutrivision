import React from 'react';
import { Sparkles, Award, Heart, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-white border-t border-pink-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-500 text-white flex items-center justify-center font-bold">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-xl font-extrabold text-slate-900 tracking-tight">NutriVision</span>
            </div>
            <p className="text-xs text-slate-600 max-w-md leading-relaxed">
              AI Nutrition & Diet Assistant powered by Multimodal Gemini 3.6 Flash. Built as an official NVIDIA Capstone Project to deliver clinical-grade food computer vision, macro tracking, and personalized diet recommendations.
            </p>
            <div className="flex items-center gap-2 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full w-fit border border-emerald-200">
              <Award className="w-3.5 h-3.5 text-emerald-600" />
              <span>NVIDIA Capstone Showcase Project</span>
            </div>
          </div>

          {/* Core Modules */}
          <div className="space-y-2 text-xs">
            <span className="font-extrabold text-slate-900 block text-sm">Core AI Modules</span>
            <ul className="space-y-1.5 font-medium text-slate-600">
              <li><button onClick={() => onNavigate('analyzer')} className="hover:text-rose-600">AI Food Analyzer</button></li>
              <li><button onClick={() => onNavigate('database')} className="hover:text-rose-600">Smart Food Database</button></li>
              <li><button onClick={() => onNavigate('recommendation')} className="hover:text-rose-600">Diet Recommendations</button></li>
              <li><button onClick={() => onNavigate('recipes')} className="hover:text-rose-600">Healthy Recipe Studio</button></li>
              <li><button onClick={() => onNavigate('chatbot')} className="hover:text-rose-600">AI Clinical Chatbot</button></li>
            </ul>
          </div>

          {/* Health Tools */}
          <div className="space-y-2 text-xs">
            <span className="font-extrabold text-slate-900 block text-sm">Biometric Tools</span>
            <ul className="space-y-1.5 font-medium text-slate-600">
              <li><button onClick={() => onNavigate('water')} className="hover:text-rose-600">Water Intake Calculator</button></li>
              <li><button onClick={() => onNavigate('bmi')} className="hover:text-rose-600">BMI & Healthy Weight Tool</button></li>
              <li><button onClick={() => onNavigate('tracker')} className="hover:text-rose-600">Daily Calorie & Meal Log</button></li>
              <li><button onClick={() => onNavigate('dashboard')} className="hover:text-rose-600">Telemetry Dashboard</button></li>
            </ul>
          </div>

        </div>

        {/* Disclaimer & Copyright */}
        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 font-medium">
          <p>© 2026 NutriVision – AI Nutrition Assistant. All rights reserved.</p>
          <p className="max-w-xl text-center sm:text-right text-[10px] text-slate-400">
            Disclaimer: NutriVision provides AI estimates based on clinical database averages. Always consult a certified dietitian or physician for personalized medical advice.
          </p>
        </div>

      </div>
    </footer>
  );
};
