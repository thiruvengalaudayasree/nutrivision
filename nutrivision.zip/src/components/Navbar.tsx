import React, { useState } from 'react';
import { 
  Sparkles, 
  Search, 
  Database, 
  Droplets, 
  Activity, 
  UtensilsCrossed, 
  ChefHat, 
  MessageSquareText, 
  LayoutDashboard, 
  Settings, 
  User, 
  Menu, 
  X,
  HeartPulse,
  LogOut
} from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: UserProfile | null;
  onOpenAuth: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  user,
  onOpenAuth,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: HeartPulse },
    { id: 'analyzer', label: 'AI Analyzer', icon: Search },
    { id: 'database', label: 'Food DB', icon: Database },
    { id: 'recommendation', label: 'Diet AI', icon: Sparkles },
    { id: 'water', label: 'Water Tracker', icon: Droplets },
    { id: 'bmi', label: 'BMI Tool', icon: Activity },
    { id: 'tracker', label: 'Meal Tracker', icon: UtensilsCrossed },
    { id: 'recipes', label: 'Recipes', icon: ChefHat },
    { id: 'chatbot', label: 'AI Chatbot', icon: MessageSquareText },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-pink-100 shadow-sm transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Capstone Badge */}
          <div 
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-2xl bg-[#F8BBD0] flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-slate-800" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-extrabold text-[#2D2D2D] tracking-tight font-display">NutriVision</span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full border border-emerald-200">
                  AI Powered
                </span>
              </div>
              <span className="text-[10px] text-rose-500 font-semibold block">NVIDIA Capstone Project</span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#FFF5F7] text-[#2D2D2D] border border-[#F8BBD0]'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-pink-50/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#F8BBD0]' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Action Button & Auth */}
          <div className="hidden sm:flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-pink-50 border border-pink-200 hover:bg-pink-100 transition-colors"
                >
                  <div className="w-7 h-7 rounded-full bg-rose-400 text-white flex items-center justify-center font-bold text-xs">
                    {user.name ? user.name[0].toUpperCase() : 'U'}
                  </div>
                  <span className="text-xs font-semibold text-slate-800 max-w-[100px] truncate">{user.name}</span>
                </button>
                <button
                  onClick={onLogout}
                  title="Logout"
                  className="p-2 rounded-full text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-all shadow-sm"
              >
                <User className="w-3.5 h-3.5" />
                Sign In / Register
              </button>
            )}
          </div>

          {/* Mobile Hamburger Toggle */}
          <div className="xl:hidden flex items-center gap-2">
            {!user && (
              <button
                onClick={onOpenAuth}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-rose-500 text-white"
              >
                Login
              </button>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-700 hover:bg-pink-50"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-pink-100 px-4 pt-2 pb-6 space-y-1.5 animate-fadeIn">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-rose-100 text-rose-900 font-bold'
                    : 'text-slate-700 hover:bg-pink-50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-rose-600' : 'text-slate-500'}`} />
                {item.label}
              </button>
            );
          })}
          {user && (
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500">Signed in as <strong className="text-slate-800">{user.name}</strong></span>
              <button
                onClick={() => {
                  onLogout();
                  setMobileMenuOpen(false);
                }}
                className="text-xs text-rose-600 font-semibold px-2 py-1 bg-rose-50 rounded"
              >
                Log Out
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
