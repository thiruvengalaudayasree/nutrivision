import React, { useState } from 'react';
import { 
  Search, 
  Flame, 
  Dumbbell, 
  Wheat, 
  Droplet, 
  Sparkles, 
  CheckCircle2, 
  X, 
  Heart, 
  Info,
  ChevronRight,
  Filter
} from 'lucide-react';
import { BUILTIN_FOOD_DATABASE } from '../data/foodDatabase';
import { FoodItem } from '../types';

interface FoodDatabaseViewProps {
  onSelectFoodToAnalyze: (foodName: string) => void;
}

export const FoodDatabaseView: React.FC<FoodDatabaseViewProps> = ({ onSelectFoodToAnalyze }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);

  const categories = [
    'All',
    'South Indian',
    'North Indian',
    'Desserts',
    'Continental & Fast Food',
    'Healthy Foods',
  ];

  const filteredFoods = BUILTIN_FOOD_DATABASE.filter(item => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-pink-600 bg-pink-100 px-3 py-1 rounded-full border border-pink-200">
          Built-In Clinical Nutrition Database
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Smart Nutrition Database
        </h2>
        <p className="text-slate-600 text-sm sm:text-base">
          Browse verified, realistic nutritional profiles for South Indian, North Indian, Desserts, Continental, and Healthy Staples. Every single food item has its own distinct profile.
        </p>
      </div>

      {/* Controls Bar */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100 space-y-4">
        
        {/* Search */}
        <div className="relative max-w-xl mx-auto">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search South Indian, Biryani, Dosa, Desserts, Fruits..."
            className="w-full pl-12 pr-4 py-3 bg-pink-50/50 border border-pink-200 rounded-2xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:bg-white transition-all"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedCategory === cat
                  ? 'bg-rose-500 text-white shadow-md shadow-rose-200'
                  : 'bg-pink-50/80 text-slate-700 hover:bg-pink-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>

      {/* Food Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredFoods.map((food) => (
          <div
            key={food.id}
            onClick={() => setSelectedFood(food)}
            className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100/80 hover:shadow-xl hover:border-pink-200 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              {/* Image / Header */}
              {food.image && (
                <div className="h-40 w-full rounded-2xl overflow-hidden mb-4 relative">
                  <img
                    src={food.image}
                    alt={food.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <span className="absolute top-3 right-3 bg-slate-900/80 backdrop-blur-md text-white text-[11px] font-bold px-2.5 py-1 rounded-full">
                    {food.nutrition.calories} kcal
                  </span>
                  <span className="absolute bottom-3 left-3 bg-emerald-500 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-md">
                    Health Score: {food.healthScore}
                  </span>
                </div>
              )}

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-pink-600 uppercase tracking-wider">
                    {food.category}
                  </span>
                  <span className="text-[11px] text-slate-500 font-semibold">
                    {food.servingSize}
                  </span>
                </div>
                <h3 className="text-xl font-black text-slate-900 group-hover:text-rose-600 transition-colors">
                  {food.name}
                </h3>
                <p className="text-xs text-slate-600 line-clamp-2">
                  {food.description}
                </p>
              </div>

              {/* Macros Summary */}
              <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-slate-100 text-center text-xs font-semibold">
                <div className="bg-rose-50/60 p-2 rounded-xl">
                  <span className="text-rose-600 font-bold block">{food.nutrition.protein}g</span>
                  <span className="text-[10px] text-slate-500">Protein</span>
                </div>
                <div className="bg-amber-50/60 p-2 rounded-xl">
                  <span className="text-amber-600 font-bold block">{food.nutrition.carbohydrates}g</span>
                  <span className="text-[10px] text-slate-500">Carbs</span>
                </div>
                <div className="bg-sky-50/60 p-2 rounded-xl">
                  <span className="text-sky-600 font-bold block">{food.nutrition.fat}g</span>
                  <span className="text-[10px] text-slate-500">Fat</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-rose-500 group-hover:translate-x-1 transition-transform">
              <span>View Full Nutrition & Advice</span>
              <ChevronRight className="w-4 h-4" />
            </div>

          </div>
        ))}
      </div>

      {/* Empty State / Not Found Prompt */}
      {filteredFoods.length === 0 && (
        <div className="text-center py-12 bg-white rounded-3xl p-8 border border-pink-100 space-y-4 max-w-lg mx-auto">
          <Sparkles className="w-10 h-10 text-pink-500 mx-auto" />
          <h3 className="text-lg font-black text-slate-900">Food Not in Default Database</h3>
          <p className="text-xs text-slate-600">
            "{searchQuery}" is not listed in our built-in database, but Multimodal Gemini AI can estimate its accurate nutrition instantly!
          </p>
          <button
            onClick={() => onSelectFoodToAnalyze(searchQuery)}
            className="px-6 py-3 bg-rose-500 text-white font-bold text-xs rounded-xl hover:bg-rose-600 transition-colors shadow-md shadow-rose-200"
          >
            Analyze "{searchQuery}" with AI Now
          </button>
        </div>
      )}

      {/* FULL DETAIL MODAL */}
      {selectedFood && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 relative max-h-[90vh] overflow-y-auto shadow-2xl my-8">
            
            <button
              onClick={() => setSelectedFood(null)}
              className="absolute top-6 right-6 p-2 rounded-full text-slate-400 hover:text-slate-800 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-2">
              <span className="px-3 py-1 bg-rose-100 text-rose-800 text-xs font-bold rounded-full">
                {selectedFood.category}
              </span>
              <h3 className="text-2xl font-black text-slate-900">{selectedFood.name}</h3>
              <p className="text-xs text-slate-600">{selectedFood.description}</p>
            </div>

            {/* Macros Row */}
            <div className="grid grid-cols-4 gap-3 text-center text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl">
                <span className="font-black text-slate-900 block text-base">{selectedFood.nutrition.calories}</span>
                <span className="text-slate-500">Calories</span>
              </div>
              <div className="p-3 bg-rose-50 rounded-2xl">
                <span className="font-black text-rose-600 block text-base">{selectedFood.nutrition.protein}g</span>
                <span className="text-slate-500">Protein</span>
              </div>
              <div className="p-3 bg-amber-50 rounded-2xl">
                <span className="font-black text-amber-600 block text-base">{selectedFood.nutrition.carbohydrates}g</span>
                <span className="text-slate-500">Carbs</span>
              </div>
              <div className="p-3 bg-sky-50 rounded-2xl">
                <span className="font-black text-sky-600 block text-base">{selectedFood.nutrition.fat}g</span>
                <span className="text-slate-500">Fat</span>
              </div>
            </div>

            {/* Micro Breakdown Table */}
            <div className="space-y-2 text-xs">
              <span className="font-extrabold text-slate-900 block text-sm">Full Micronutrient Spectrum</span>
              <div className="grid grid-cols-2 gap-x-6 gap-y-2 p-4 bg-pink-50/30 rounded-2xl border border-pink-100">
                <div className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-slate-600">Fiber</span>
                  <span className="font-bold text-slate-900">{selectedFood.nutrition.fiber}g</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-slate-600">Sugar</span>
                  <span className="font-bold text-slate-900">{selectedFood.nutrition.sugar}g</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-slate-600">Sodium</span>
                  <span className="font-bold text-slate-900">{selectedFood.nutrition.sodium}mg</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-slate-600">Potassium</span>
                  <span className="font-bold text-slate-900">{selectedFood.nutrition.potassium}mg</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-slate-600">Calcium</span>
                  <span className="font-bold text-slate-900">{selectedFood.nutrition.calcium}mg</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 py-1">
                  <span className="text-slate-600">Iron</span>
                  <span className="font-bold text-slate-900">{selectedFood.nutrition.iron}mg</span>
                </div>
              </div>
            </div>

            {/* Diet Advice Snippet */}
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-xs space-y-1">
              <span className="font-extrabold text-emerald-900 block">AI Clinical Advice:</span>
              <p className="text-slate-700"><strong>Weight Loss:</strong> {selectedFood.recommendation.weightLossAdvice}</p>
              <p className="text-slate-700"><strong>Diabetes:</strong> {selectedFood.recommendation.diabetesAdvice}</p>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  onSelectFoodToAnalyze(selectedFood.name);
                  setSelectedFood(null);
                }}
                className="w-full py-3 bg-rose-500 text-white font-bold text-xs rounded-2xl hover:bg-rose-600 transition-colors shadow"
              >
                Open Full AI Analysis View
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
