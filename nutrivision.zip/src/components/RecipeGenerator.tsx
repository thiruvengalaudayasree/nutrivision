import React, { useState } from 'react';
import { 
  ChefHat, 
  Sparkles, 
  Clock, 
  Flame, 
  CheckCircle2, 
  Utensils, 
  Dumbbell, 
  TrendingDown, 
  Heart,
  ChevronRight
} from 'lucide-react';
import { Recipe } from '../types';
import { generateRecipe } from '../services/api';

export const RecipeGenerator: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Weight Loss');
  const [prompt, setPrompt] = useState<string>('');
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const categories = [
    'Weight Loss',
    'Muscle Building',
    'High Protein',
    'Keto Friendly',
    'Low Carb',
    'Diabetic Friendly',
    'Vegetarian',
    'Vegan',
  ];

  const handleGenerate = async (cat?: string) => {
    const targetCat = cat || selectedCategory;
    setSelectedCategory(targetCat);
    setLoading(true);

    try {
      const result = await generateRecipe(targetCat, prompt || `Create an easy, delicious recipe for ${targetCat}.`);
      setRecipe(result);
    } catch (err) {
      console.error('Error generating recipe:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-pink-600 bg-pink-100 px-3 py-1 rounded-full border border-pink-200">
          AI Clinical Culinary Studio
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          AI Healthy Recipe Generator
        </h2>
        <p className="text-slate-600 text-sm sm:text-base">
          Generate delicious, nutrient-calculated recipes tailored to your dietary goal (Weight Loss, High Protein, Diabetic Friendly, Keto, Vegan).
        </p>
      </div>

      {/* Target Category Selector */}
      <div className="max-w-3xl mx-auto bg-white rounded-3xl p-6 shadow-sm border border-pink-100 space-y-4">
        
        <label className="block text-xs font-bold text-slate-700">Select Target Goal:</label>
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => handleGenerate(cat)}
              disabled={loading}
              className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                selectedCategory === cat
                  ? 'bg-rose-500 text-white shadow-md shadow-rose-200'
                  : 'bg-pink-50 text-slate-700 hover:bg-pink-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Custom Prompt Optional Input */}
        <div className="pt-2 flex gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g. Include paneer and spinach, or no mushrooms..."
            className="w-full px-4 py-3 bg-pink-50/50 border border-pink-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-rose-400"
          />
          <button
            onClick={() => handleGenerate()}
            disabled={loading}
            className="px-6 py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold text-xs rounded-2xl transition-all shrink-0 flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
            Generate
          </button>
        </div>

      </div>

      {loading && (
        <div className="py-12 text-center space-y-3">
          <ChefHat className="w-10 h-10 text-rose-500 animate-bounce mx-auto" />
          <p className="font-extrabold text-slate-800 text-base">Gemini AI is crafting your custom recipe...</p>
          <p className="text-xs text-slate-500">Calculating exact portion macros, ingredients, and instructions.</p>
        </div>
      )}

      {/* RECIPE DISPLAY CARD */}
      {recipe && !loading && (
        <div className="max-w-4xl mx-auto bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-pink-100 space-y-8 animate-fadeIn">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-6">
            <div>
              <span className="px-3 py-1 bg-rose-100 text-rose-800 text-xs font-bold rounded-full">
                {recipe.dietaryCategory}
              </span>
              <h3 className="text-3xl font-black text-slate-900 mt-2">{recipe.title}</h3>
              <p className="text-xs text-slate-600 mt-1">{recipe.description}</p>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 px-4 py-3 rounded-2xl text-center shrink-0">
              <span className="text-xs font-bold text-emerald-800 uppercase block">Health Score</span>
              <span className="text-2xl font-black text-emerald-600">{recipe.healthScore}/100</span>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center text-xs font-semibold">
            <div className="p-3 bg-pink-50/50 rounded-2xl border border-pink-100">
              <Clock className="w-4 h-4 text-slate-500 mx-auto mb-1" />
              <span className="font-bold text-slate-900 block">{recipe.prepTime} Prep / {recipe.cookTime} Cook</span>
              <span className="text-[10px] text-slate-400">Time</span>
            </div>

            <div className="p-3 bg-rose-50/50 rounded-2xl border border-rose-100">
              <Flame className="w-4 h-4 text-orange-500 mx-auto mb-1" />
              <span className="font-bold text-slate-900 block">{recipe.caloriesPerServing} kcal</span>
              <span className="text-[10px] text-slate-400">Calories / Serving</span>
            </div>

            <div className="p-3 bg-amber-50/50 rounded-2xl border border-amber-100">
              <Dumbbell className="w-4 h-4 text-rose-500 mx-auto mb-1" />
              <span className="font-bold text-rose-600 block">{recipe.protein}g Protein</span>
              <span className="text-[10px] text-slate-400">Macro Split</span>
            </div>

            <div className="p-3 bg-sky-50/50 rounded-2xl border border-sky-100">
              <Utensils className="w-4 h-4 text-sky-500 mx-auto mb-1" />
              <span className="font-bold text-sky-600 block">C: {recipe.carbs}g | F: {recipe.fat}g</span>
              <span className="text-[10px] text-slate-400">Carbs & Fat</span>
            </div>
          </div>

          {/* Ingredients */}
          <div className="space-y-3">
            <h4 className="text-base font-extrabold text-slate-900">Ingredients ({recipe.servings} Servings):</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {recipe.ingredients.map((ing, i) => (
                <label key={i} className="flex items-center gap-2 p-2.5 rounded-xl bg-pink-50/30 border border-pink-100 text-slate-800 cursor-pointer">
                  <input type="checkbox" className="accent-rose-500 rounded" />
                  <span>{ing}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Cooking Instructions */}
          <div className="space-y-3">
            <h4 className="text-base font-extrabold text-slate-900">Cooking Steps:</h4>
            <ol className="space-y-3 text-xs text-slate-700">
              {recipe.instructions.map((step, i) => (
                <li key={i} className="flex items-start gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
                  <span className="w-6 h-6 rounded-full bg-rose-500 text-white font-bold flex items-center justify-center shrink-0 text-[11px]">
                    {i + 1}
                  </span>
                  <p className="pt-0.5 leading-relaxed">{step}</p>
                </li>
              ))}
            </ol>
          </div>

        </div>
      )}

    </div>
  );
};
