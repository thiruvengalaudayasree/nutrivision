import React, { useState } from 'react';
import { 
  UtensilsCrossed, 
  Plus, 
  Trash2, 
  Flame, 
  Dumbbell, 
  Wheat, 
  Droplet, 
  Calendar,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { LoggedMeal } from '../types';

interface MealTrackerProps {
  loggedMeals: LoggedMeal[];
  onAddMeal: (meal: Omit<LoggedMeal, 'id' | 'timestamp'>) => void;
  onRemoveMeal: (id: string) => void;
  onClearAll: () => void;
}

export const MealTracker: React.FC<MealTrackerProps> = ({
  loggedMeals,
  onAddMeal,
  onRemoveMeal,
  onClearAll,
}) => {
  const [foodName, setFoodName] = useState('');
  const [mealType, setMealType] = useState<'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks'>('Breakfast');
  const [calories, setCalories] = useState<number>(300);
  const [protein, setProtein] = useState<number>(15);
  const [carbs, setCarbs] = useState<number>(40);
  const [fat, setFat] = useState<number>(10);
  const [serving, setServing] = useState('1 serving');

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName.trim()) return;

    onAddMeal({
      foodName: foodName.trim(),
      mealType,
      calories: Number(calories),
      protein: Number(protein),
      carbs: Number(carbs),
      fat: Number(fat),
      serving,
      date: new Date().toISOString().split('T')[0],
    });

    setFoodName('');
  };

  // Totals
  const totalCalories = loggedMeals.reduce((acc, m) => acc + m.calories, 0);
  const totalProtein = loggedMeals.reduce((acc, m) => acc + m.protein, 0);
  const totalCarbs = loggedMeals.reduce((acc, m) => acc + m.carbs, 0);
  const totalFat = loggedMeals.reduce((acc, m) => acc + m.fat, 0);

  const mealCategories: ('Breakfast' | 'Lunch' | 'Dinner' | 'Snacks')[] = ['Breakfast', 'Lunch', 'Dinner', 'Snacks'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-pink-600 bg-pink-100 px-3 py-1 rounded-full border border-pink-200">
          Daily Caloric & Macro Registry
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Daily Nutrition & Meal Tracker
        </h2>
        <p className="text-slate-600 text-sm sm:text-base">
          Log breakfast, lunch, dinner, and snacks to keep an accurate record of your daily macronutrient totals.
        </p>
      </div>

      {/* Daily Totals Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100 text-center">
          <Flame className="w-6 h-6 text-orange-500 mx-auto mb-1" />
          <span className="text-3xl font-black text-slate-900">{totalCalories}</span>
          <span className="text-xs font-bold text-slate-500 block">Total Calories (kcal)</span>
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100 text-center">
          <Dumbbell className="w-6 h-6 text-rose-500 mx-auto mb-1" />
          <span className="text-3xl font-black text-rose-600">{totalProtein.toFixed(1)}g</span>
          <span className="text-xs font-bold text-slate-500 block">Total Protein</span>
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100 text-center">
          <Wheat className="w-6 h-6 text-amber-500 mx-auto mb-1" />
          <span className="text-3xl font-black text-amber-600">{totalCarbs.toFixed(1)}g</span>
          <span className="text-xs font-bold text-slate-500 block">Total Carbs</span>
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100 text-center">
          <Droplet className="w-6 h-6 text-sky-500 mx-auto mb-1" />
          <span className="text-3xl font-black text-sky-600">{totalFat.toFixed(1)}g</span>
          <span className="text-xs font-bold text-slate-500 block">Total Fat</span>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Quick Add Meal Form */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 shadow-md border border-pink-100 space-y-4">
          <h3 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
            <Plus className="w-5 h-5 text-rose-500" />
            Quick Log Custom Meal
          </h3>

          <form onSubmit={handleManualAdd} className="space-y-3 text-xs font-semibold text-slate-700">
            <div>
              <label className="block mb-1">Meal Name</label>
              <input
                type="text"
                value={foodName}
                onChange={(e) => setFoodName(e.target.value)}
                placeholder="e.g. Oats with Berries, Grilled Paneer..."
                required
                className="w-full p-2.5 bg-pink-50/50 border border-pink-200 rounded-xl"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block mb-1">Meal Time</label>
                <select
                  value={mealType}
                  onChange={(e) => setMealType(e.target.value as any)}
                  className="w-full p-2.5 bg-pink-50/50 border border-pink-200 rounded-xl font-medium"
                >
                  <option value="Breakfast">Breakfast</option>
                  <option value="Lunch">Lunch</option>
                  <option value="Dinner">Dinner</option>
                  <option value="Snacks">Snacks</option>
                </select>
              </div>

              <div>
                <label className="block mb-1">Serving Portion</label>
                <input
                  type="text"
                  value={serving}
                  onChange={(e) => setServing(e.target.value)}
                  className="w-full p-2.5 bg-pink-50/50 border border-pink-200 rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block mb-1">Calories (kcal)</label>
                <input
                  type="number"
                  value={calories}
                  onChange={(e) => setCalories(Number(e.target.value))}
                  className="w-full p-2.5 bg-pink-50/50 border border-pink-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block mb-1">Protein (g)</label>
                <input
                  type="number"
                  value={protein}
                  onChange={(e) => setProtein(Number(e.target.value))}
                  className="w-full p-2.5 bg-pink-50/50 border border-pink-200 rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block mb-1">Carbs (g)</label>
                <input
                  type="number"
                  value={carbs}
                  onChange={(e) => setCarbs(Number(e.target.value))}
                  className="w-full p-2.5 bg-pink-50/50 border border-pink-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block mb-1">Fat (g)</label>
                <input
                  type="number"
                  value={fat}
                  onChange={(e) => setFat(Number(e.target.value))}
                  className="w-full p-2.5 bg-pink-50/50 border border-pink-200 rounded-xl"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl transition-colors shadow-md shadow-rose-200 mt-2"
            >
              Add Meal to Daily Log
            </button>
          </form>
        </div>

        {/* Logged Meals List by Category */}
        <div className="lg:col-span-7 space-y-6">
          
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black text-slate-900">Today's Logged Meals</h3>
            {loggedMeals.length > 0 && (
              <button
                onClick={onClearAll}
                className="text-xs font-bold text-rose-600 hover:bg-rose-50 px-3 py-1.5 rounded-xl transition-colors"
              >
                Clear Log
              </button>
            )}
          </div>

          {loggedMeals.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-pink-100 text-center space-y-2">
              <UtensilsCrossed className="w-10 h-10 text-pink-300 mx-auto" />
              <p className="font-extrabold text-slate-800">No Meals Logged Yet Today</p>
              <p className="text-xs text-slate-500">
                Use the quick form on the left or analyze food in the AI Analyzer to add items directly!
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {mealCategories.map((cat) => {
                const mealsInCat = loggedMeals.filter((m) => m.mealType === cat);
                if (mealsInCat.length === 0) return null;

                const catCalories = mealsInCat.reduce((acc, m) => acc + m.calories, 0);

                return (
                  <div key={cat} className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="font-extrabold text-slate-900 text-sm">{cat}</span>
                      <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-full">
                        {catCalories} kcal
                      </span>
                    </div>

                    <div className="space-y-2">
                      {mealsInCat.map((meal) => (
                        <div key={meal.id} className="flex items-center justify-between p-3 rounded-2xl bg-pink-50/30 text-xs">
                          <div>
                            <span className="font-bold text-slate-900 block">{meal.foodName}</span>
                            <span className="text-slate-500">
                              {meal.serving} • P: {meal.protein}g | C: {meal.carbs}g | F: {meal.fat}g
                            </span>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="font-extrabold text-slate-800">{meal.calories} kcal</span>
                            <button
                              onClick={() => onRemoveMeal(meal.id)}
                              className="text-slate-400 hover:text-rose-600 p-1"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
