import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  User, 
  Send, 
  Sparkles, 
  MessageSquare, 
  Lightbulb,
  HeartPulse,
  Flame
} from 'lucide-react';
import { sendChatMessage } from '../services/api';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

export const ChatbotView: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'bot',
      text: "Hello! I am NutriBot, your AI Clinical Nutritionist & Fitness Assistant. Ask me anything about calorie goals, meal planning, macro splits, water intake, diabetes diets, or weight management!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedPrompts = [
    "How much water should I drink daily for weight loss?",
    "Give me a high-protein 2000 calorie vegetarian plan.",
    "Which foods help manage Type 2 Diabetes?",
    "Best pre-workout and post-workout meal ideas?",
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (customText?: string) => {
    const messageText = customText || input;
    if (!messageText.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: 'usr-' + Date.now(),
      sender: 'user',
      text: messageText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customText) setInput('');
    setLoading(true);

    try {
      const responseText = await sendChatMessage(messageText);
      const botMsg: ChatMessage = {
        id: 'bot-' + Date.now(),
        sender: 'bot',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      console.error('Chat error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <span className="text-xs font-extrabold uppercase tracking-widest text-pink-600 bg-pink-100 px-3 py-1 rounded-full border border-pink-200">
          Gemini 3.6 Flash Engine
        </span>
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">
          AI Clinical Nutrition Chatbot
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm">
          Get real-time answers to your nutrition, diet, fitness, and health questions from NutriBot.
        </p>
      </div>

      {/* Suggested Prompts Bar */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {suggestedPrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            disabled={loading}
            className="px-3.5 py-2 bg-white hover:bg-pink-50 border border-pink-200 rounded-2xl text-xs font-bold text-slate-700 transition-all shadow-sm flex items-center gap-1.5"
          >
            <Lightbulb className="w-3.5 h-3.5 text-rose-500" />
            <span>{prompt}</span>
          </button>
        ))}
      </div>

      {/* Chat Messages Box */}
      <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-xl border border-pink-100 flex flex-col h-[520px]">
        
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${
                msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 shadow-sm ${
                  msg.sender === 'user'
                    ? 'bg-slate-900 text-white font-bold text-xs'
                    : 'bg-rose-500 text-white'
                }`}
              >
                {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-5 h-5" />}
              </div>

              <div
                className={`max-w-md sm:max-w-lg p-4 rounded-3xl text-xs sm:text-sm leading-relaxed space-y-1 shadow-sm ${
                  msg.sender === 'user'
                    ? 'bg-rose-500 text-white rounded-tr-none'
                    : 'bg-pink-50/80 text-slate-800 rounded-tl-none border border-pink-100'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
                <span className={`text-[10px] block text-right font-medium opacity-70 ${
                  msg.sender === 'user' ? 'text-rose-100' : 'text-slate-400'
                }`}>
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-rose-500 text-white flex items-center justify-center">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div className="px-4 py-3 bg-pink-50 rounded-2xl text-xs font-bold text-slate-600 animate-pulse">
                NutriBot is analyzing health insights...
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input Box */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="pt-4 border-t border-slate-100 flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about calories, high-protein foods, water intake..."
            className="flex-1 px-4 py-3 bg-pink-50/50 border border-pink-200 rounded-2xl text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:bg-white"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="p-3 bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white rounded-2xl transition-all shadow-md shadow-rose-200"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>

    </div>
  );
};
