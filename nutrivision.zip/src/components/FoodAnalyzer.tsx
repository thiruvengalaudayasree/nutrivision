import React, { useState, useRef } from 'react';
import { 
  Search, 
  Upload, 
  Camera, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  Flame, 
  Dumbbell, 
  Wheat, 
  Droplet, 
  ShieldCheck, 
  Heart, 
  Zap, 
  Bookmark, 
  Plus, 
  Activity, 
  Info,
  Clock,
  TrendingDown,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { FoodItem, LoggedMeal } from '../types';
import { analyzeFoodItem } from '../services/api';

interface FoodAnalyzerProps {
  onLogMeal: (meal: Omit<LoggedMeal, 'id' | 'timestamp'>) => void;
}

export const FoodAnalyzer: React.FC<FoodAnalyzerProps> = ({ onLogMeal }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [analyzedFood, setAnalyzedFood] = useState<FoodItem | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Search by Text
  const handleTextSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setErrorMsg(null);
    setAnalyzedFood(null);

    try {
      const result = await analyzeFoodItem({ foodName: searchQuery.trim() });
      setAnalyzedFood(result);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to analyze food. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Upload Image
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      setLoading(true);
      setErrorMsg(null);
      setAnalyzedFood(null);

      try {
        const result = await analyzeFoodItem({ imageBase64: base64 });
        setAnalyzedFood(result);
      } catch (err: any) {
        setErrorMsg('Could not process the uploaded food image.');
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Start Camera
  const startCamera = async () => {
    setCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      alert('Camera access denied or unavailable. Please use image upload.');
      setCameraActive(false);
    }
  };

  // Capture Camera Frame
  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const base64 = canvas.toDataURL('image/jpeg');
      
      // Stop Camera Stream
      const stream = videoRef.current.srcObject as MediaStream;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      setCameraActive(false);

      setLoading(true);
      setErrorMsg(null);
      setAnalyzedFood(null);

      analyzeFoodItem({ imageBase64: base64 })
        .then(result => setAnalyzedFood(result))
        .catch(() => setErrorMsg('Failed to identify captured image.'))
        .finally(() => setLoading(false));
    }
  };

  const handleQuickAdd = (mealType: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks') => {
    if (!analyzedFood) return;
    onLogMeal({
      foodName: analyzedFood.name,
      mealType,
      calories: analyzedFood.nutrition.calories,
      protein: analyzedFood.nutrition.protein,
      carbs: analyzedFood.nutrition.carbohydrates,
      fat: analyzedFood.nutrition.fat,
      serving: analyzedFood.servingSize,
      date: new Date().toISOString().split('T')[0],
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-extrabold uppercase tracking-widest text-pink-600 bg-pink-100 px-3 py-1 rounded-full border border-pink-200">
          Multimodal Gemini AI Engine
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          AI Food Nutrition Analyzer
        </h2>
        <p className="text-slate-600 text-sm sm:text-base">
          Search any dish, upload a meal photo, or capture food using your camera to receive an instant, accurate nutritional breakdown & personalized health advice.
        </p>
      </div>

      {/* Input Options Card */}
      <div className="max-w-3xl mx-auto bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-pink-100 space-y-6">
        
        {/* Search Bar */}
        <form onSubmit={handleTextSearch} className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search food by name (e.g. Masala Dosa, Butter Chicken, Apple)..."
              className="w-full pl-12 pr-4 py-3.5 bg-pink-50/50 border border-pink-200 rounded-2xl text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-400 focus:bg-white transition-all"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !searchQuery.trim()}
            className="px-6 py-3.5 bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white font-bold text-sm rounded-2xl transition-all shadow-md shadow-rose-200 shrink-0"
          >
            Analyze
          </button>
        </form>

        <div className="flex items-center justify-center gap-4 text-xs font-semibold text-slate-400">
          <div className="h-px bg-slate-200 flex-1" />
          <span>OR USE MULTIMODAL INPUT</span>
          <div className="h-px bg-slate-200 flex-1" />
        </div>

        {/* Upload & Camera Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={loading}
            className="flex items-center justify-center gap-2.5 p-4 rounded-2xl border-2 border-dashed border-rose-200 bg-pink-50/40 hover:bg-rose-50 text-slate-800 text-xs font-bold transition-all hover:border-rose-400"
          >
            <Upload className="w-4 h-4 text-rose-500" />
            Upload Food Photo
          </button>

          <button
            onClick={startCamera}
            disabled={loading}
            className="flex items-center justify-center gap-2.5 p-4 rounded-2xl border-2 border-dashed border-rose-200 bg-pink-50/40 hover:bg-rose-50 text-slate-800 text-xs font-bold transition-all hover:border-rose-400"
          >
            <Camera className="w-4 h-4 text-rose-500" />
            Capture with Camera
          </button>
        </div>

        {/* Live Camera Modal */}
        {cameraActive && (
          <div className="p-4 bg-slate-900 rounded-2xl text-center space-y-3">
            <video ref={videoRef} autoPlay playsInline className="w-full max-h-64 object-cover rounded-xl mx-auto" />
            <div className="flex justify-center gap-3">
              <button
                onClick={capturePhoto}
                className="px-5 py-2 bg-rose-500 text-white font-bold text-xs rounded-xl shadow"
              >
                Snap & Analyze
              </button>
              <button
                onClick={() => {
                  const stream = videoRef.current?.srcObject as MediaStream;
                  stream?.getTracks().forEach(t => t.stop());
                  setCameraActive(false);
                }}
                className="px-4 py-2 bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

      </div>

      {/* Loading Indicator */}
      {loading && (
        <div className="py-12 text-center space-y-4 animate-pulse">
          <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-500 flex items-center justify-center mx-auto">
            <Sparkles className="w-8 h-8 animate-spin" />
          </div>
          <p className="text-slate-800 font-bold text-lg">Gemini AI is analyzing nutrition facts...</p>
          <p className="text-xs text-slate-500">Estimating macros, vitamins, glycemic index, and personalized diet tips.</p>
        </div>
      )}

      {/* Error Message */}
      {errorMsg && (
        <div className="max-w-2xl mx-auto p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-sm font-semibold flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Notification Toast */}
      {savedNotice && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 text-xs font-bold animate-slideUp">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Logged meal successfully to Daily Tracker!</span>
        </div>
      )}

      {/* ANALYSIS RESULTS CARD */}
      {analyzedFood && !loading && (
        <div className="space-y-8 animate-fadeIn">
          
          {/* Main Top Header Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-lg border border-pink-100 relative overflow-hidden">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
              
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-3 py-1 bg-rose-100 text-rose-800 text-xs font-bold rounded-full">
                    {analyzedFood.category}
                  </span>
                  <span className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded-full">
                    Serving: {analyzedFood.servingSize}
                  </span>
                </div>
                <h3 className="text-3xl font-black text-slate-900">{analyzedFood.name}</h3>
                <p className="text-slate-600 text-sm mt-1 max-w-xl">{analyzedFood.description}</p>
              </div>

              {/* Health Score Meter & Quick Log Actions */}
              <div className="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center min-w-[130px]">
                  <span className="text-xs font-bold text-emerald-800 uppercase block">Health Score</span>
                  <span className="text-3xl font-black text-emerald-600">{analyzedFood.healthScore}</span>
                  <span className="text-[10px] text-emerald-700 font-semibold block">out of 100</span>
                </div>

                <div className="space-y-2 w-full sm:w-auto">
                  <span className="text-xs font-bold text-slate-700 block">Log to Today's Meals:</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['Breakfast', 'Lunch', 'Dinner', 'Snacks'] as const).map(type => (
                      <button
                        key={type}
                        onClick={() => handleQuickAdd(type)}
                        className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-bold rounded-xl border border-rose-200 transition-colors flex items-center justify-center gap-1"
                      >
                        <Plus className="w-3 h-3" />
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

              </div>

            </div>

            {/* Diet Badges Row */}
            <div className="flex flex-wrap items-center gap-2 pt-6 mt-6 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-500 mr-2">Dietary Badges:</span>
              {analyzedFood.dietBadges.vegetarian && (
                <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-lg flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Vegetarian
                </span>
              )}
              {analyzedFood.dietBadges.vegan && (
                <span className="px-3 py-1 bg-green-100 text-green-800 text-xs font-bold rounded-lg flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> Vegan
                </span>
              )}
              {analyzedFood.dietBadges.glutenFree && (
                <span className="px-3 py-1 bg-amber-100 text-amber-800 text-xs font-bold rounded-lg flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" /> Gluten Free
                </span>
              )}
              {analyzedFood.dietBadges.highProtein && (
                <span className="px-3 py-1 bg-rose-100 text-rose-800 text-xs font-bold rounded-lg flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-rose-600" /> High Protein
                </span>
              )}
              {analyzedFood.dietBadges.ketoFriendly && (
                <span className="px-3 py-1 bg-sky-100 text-sky-800 text-xs font-bold rounded-lg flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-sky-600" /> Keto Friendly
                </span>
              )}
              {analyzedFood.dietBadges.diabeticFriendly && (
                <span className="px-3 py-1 bg-purple-100 text-purple-800 text-xs font-bold rounded-lg flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-purple-600" /> Diabetic Friendly
                </span>
              )}
              <span className="px-3 py-1 bg-slate-100 text-slate-800 text-xs font-bold rounded-lg">
                GI Index: {analyzedFood.glycemicIndex}
              </span>
            </div>

          </div>

          {/* Core Macros Overview Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            
            <div className="bg-white rounded-2xl p-5 border border-pink-100 shadow-sm text-center">
              <Flame className="w-6 h-6 text-orange-500 mx-auto mb-1" />
              <span className="text-2xl font-black text-slate-900">{analyzedFood.nutrition.calories}</span>
              <span className="text-xs font-bold text-slate-500 block">Calories (kcal)</span>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-pink-100 shadow-sm text-center">
              <Dumbbell className="w-6 h-6 text-rose-500 mx-auto mb-1" />
              <span className="text-2xl font-black text-rose-600">{analyzedFood.nutrition.protein}g</span>
              <span className="text-xs font-bold text-slate-500 block">Protein</span>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-pink-100 shadow-sm text-center">
              <Wheat className="w-6 h-6 text-amber-500 mx-auto mb-1" />
              <span className="text-2xl font-black text-amber-600">{analyzedFood.nutrition.carbohydrates}g</span>
              <span className="text-xs font-bold text-slate-500 block">Carbohydrates</span>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-pink-100 shadow-sm text-center">
              <Droplet className="w-6 h-6 text-sky-500 mx-auto mb-1" />
              <span className="text-2xl font-black text-sky-600">{analyzedFood.nutrition.fat}g</span>
              <span className="text-xs font-bold text-slate-500 block">Total Fats</span>
            </div>

          </div>

          {/* Detailed Micronutrients Breakdown Grid */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-pink-100 space-y-6">
            <h4 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Activity className="w-5 h-5 text-rose-500" />
              Comprehensive Nutritional Spectrum
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
              
              {/* Fibers & Sugars */}
              <div className="space-y-3 p-4 rounded-2xl bg-pink-50/30 border border-pink-100">
                <span className="font-extrabold text-slate-800 block text-sm border-b border-pink-100 pb-2">Fiber & Sugars</span>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Dietary Fiber</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.fiber} g</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Natural Sugar</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.sugar} g</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-600 font-semibold">Glycemic Index</span>
                  <span className="font-bold text-slate-900">{analyzedFood.glycemicIndex}</span>
                </div>
              </div>

              {/* Essential Minerals */}
              <div className="space-y-3 p-4 rounded-2xl bg-pink-50/30 border border-pink-100">
                <span className="font-extrabold text-slate-800 block text-sm border-b border-pink-100 pb-2">Minerals & Electrolytes</span>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Sodium</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.sodium} mg</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Potassium</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.potassium} mg</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Calcium</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.calcium} mg</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-600 font-semibold">Iron</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.iron} mg</span>
                </div>
              </div>

              {/* Essential Vitamins */}
              <div className="space-y-3 p-4 rounded-2xl bg-pink-50/30 border border-pink-100">
                <span className="font-extrabold text-slate-800 block text-sm border-b border-pink-100 pb-2">Key Vitamins</span>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Vitamin A</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.vitaminA} mcg</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Vitamin C</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.vitaminC} mg</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-semibold">Vitamin D</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.vitaminD} mcg</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-600 font-semibold">Vitamin B12</span>
                  <span className="font-bold text-slate-900">{analyzedFood.nutrition.vitaminB12} mcg</span>
                </div>
              </div>

            </div>
          </div>

          {/* AI DIET RECOMMENDATION SECTION */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-pink-100 space-y-6">
            <h4 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-pink-600" />
              AI Diet Recommendation & Health Guidance
            </h4>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
              
              {/* Benefits */}
              <div className="p-5 rounded-2xl bg-emerald-50/60 border border-emerald-200 space-y-2">
                <span className="font-extrabold text-emerald-900 text-sm flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Health Benefits
                </span>
                <ul className="space-y-1.5 text-slate-700">
                  {analyzedFood.recommendation.benefits.map((b, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Drawbacks */}
              <div className="p-5 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-2">
                <span className="font-extrabold text-amber-900 text-sm flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-600" /> Considerations & Drawbacks
                </span>
                <ul className="space-y-1.5 text-slate-700">
                  {analyzedFood.recommendation.drawbacks.map((d, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>

            {/* Specific Goal Advice Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              
              <div className="p-4 rounded-2xl border border-pink-100 bg-pink-50/20 space-y-1">
                <span className="font-bold text-rose-800 block flex items-center gap-1">
                  <TrendingDown className="w-3.5 h-3.5 text-rose-500" /> Weight Loss Advice
                </span>
                <p className="text-slate-700">{analyzedFood.recommendation.weightLossAdvice}</p>
              </div>

              <div className="p-4 rounded-2xl border border-pink-100 bg-pink-50/20 space-y-1">
                <span className="font-bold text-emerald-800 block flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-500" /> Weight Gain Advice
                </span>
                <p className="text-slate-700">{analyzedFood.recommendation.weightGainAdvice}</p>
              </div>

              <div className="p-4 rounded-2xl border border-pink-100 bg-pink-50/20 space-y-1">
                <span className="font-bold text-sky-800 block flex items-center gap-1">
                  <Dumbbell className="w-3.5 h-3.5 text-sky-500" /> Muscle Building Advice
                </span>
                <p className="text-slate-700">{analyzedFood.recommendation.muscleBuildingAdvice}</p>
              </div>

              <div className="p-4 rounded-2xl border border-pink-100 bg-pink-50/20 space-y-1">
                <span className="font-bold text-purple-800 block flex items-center gap-1">
                  <Activity className="w-3.5 h-3.5 text-purple-500" /> Diabetes Advice
                </span>
                <p className="text-slate-700">{analyzedFood.recommendation.diabetesAdvice}</p>
              </div>

              <div className="p-4 rounded-2xl border border-pink-100 bg-pink-50/20 space-y-1">
                <span className="font-bold text-red-800 block flex items-center gap-1">
                  <Heart className="w-3.5 h-3.5 text-red-500" /> Heart Health Advice
                </span>
                <p className="text-slate-700">{analyzedFood.recommendation.heartHealthAdvice}</p>
              </div>

              <div className="p-4 rounded-2xl border border-pink-100 bg-pink-50/20 space-y-1">
                <span className="font-bold text-indigo-800 block flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-indigo-500" /> Best Time to Eat
                </span>
                <p className="text-slate-700">{analyzedFood.recommendation.bestTimeToEat}</p>
              </div>

            </div>

            {/* Healthier Alternatives */}
            <div className="pt-2">
              <span className="text-xs font-bold text-slate-700 block mb-2">Recommended Healthier Alternatives:</span>
              <div className="flex flex-wrap gap-2">
                {analyzedFood.recommendation.healthierAlternatives.map((alt, idx) => (
                  <span key={idx} className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg">
                    {alt}
                  </span>
                ))}
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
